#ifndef MOONSHINE_TTS_PIPER_TTS_H
#define MOONSHINE_TTS_PIPER_TTS_H

#include <cstdint>
#include <filesystem>
#include <memory>
#include <optional>
#include <string>
#include <string_view>
#include <vector>

#include "file-information.h"
#include "moonshine-g2p-options.h"

namespace moonshine_tts {

/// Piper ONNX TTS + ``MoonshineG2P`` IPA (filtered to each model's
/// ``phoneme_id_map``; no eSpeak at runtime).
struct PiperTTSOptions {
  /// When non-empty, load this ``*.onnx`` directly; ``voices_dir`` / discovery
  /// is skipped. Config JSON defaults to ``explicit_onnx_path`` with
  /// ``.onnx.json`` (same folder) unless
  /// ``explicit_onnx_json_path`` is set.
  std::filesystem::path explicit_onnx_path{};
  /// Piper model config (``*.onnx.json``). Empty → beside
  /// ``explicit_onnx_path`` or, when using
  /// ``voices_dir`` discovery, ``voices_json_dir / (<onnx_filename> +
  /// ".json")`` if ``voices_json_dir`` is non-empty, else beside the chosen
  /// ``*.onnx``.
  std::filesystem::path explicit_onnx_json_path{};
  /// Directory containing ``*.onnx`` for the resolved language. Empty →
  /// ``g2p_options.g2p_root / <lang-subdir> / piper-voices`` unless
  /// ``explicit_onnx_path`` is set
  /// (``g2p_root`` defaults to the process cwd when empty).
  std::filesystem::path voices_dir{};
  /// Optional directory containing ``*.onnx.json`` files whose basenames match
  /// ``*.onnx`` in
  /// ``voices_dir`` (``<name>.onnx`` → ``<name>.onnx.json`` in this folder).
  /// Empty → JSON beside ONNX.
  std::filesystem::path voices_json_dir{};
  /// Locale tag (e.g. ``en_us``, ``de``, ``es``, ``es-ES``, ``ar_msa``).
  std::string lang = "en_us";
  /// ONNX basename (e.g. ``en_US-lessac-medium.onnx``) or stem; empty → default
  /// for ``lang``.
  std::string onnx_model{};
  double speed = 1.0;
  MoonshineG2POptions g2p_options{};
  std::vector<std::string> ort_provider_names{};
  std::string coreml_cache_dir{};
  /// Match ``piper-tts`` ``SynthesisConfig.normalize_audio`` (scale chunk to
  /// full range before clip).
  bool normalize_audio = true;
  /// Match ``SynthesisConfig.volume`` (applied after normalize).
  float output_volume = 1.F;
  /// When set, replaces JSON ``inference.noise_scale`` for ORT (``0`` matches
  /// deterministic ``speak.py`` parity tests).
  std::optional<float> piper_noise_scale_override{};
  /// When set, replaces JSON ``inference.noise_w`` for ORT.
  std::optional<float> piper_noise_w_override{};
  /// Optional in-memory TTS assets (keys ``piper/onnx``, ``piper/onnx.json``)
  /// from ``MoonshineTTSOptions::files``.
  FileInformationMap tts_asset_files{};
};

class PiperTTS {
 public:
  explicit PiperTTS(const PiperTTSOptions& opt);
  PiperTTS(const PiperTTS&) = delete;
  PiperTTS& operator=(const PiperTTS&) = delete;
  PiperTTS(PiperTTS&&) noexcept;
  PiperTTS& operator=(PiperTTS&&) noexcept;
  ~PiperTTS();

  void set_lang(std::string_view lang_cli);
  void set_speed(double speed);
  double speed() const;
  /// Basename or stem of an ``.onnx`` under ``voices_dir``.
  void set_onnx_model(std::string_view basename_or_stem);
  /// Post-synthesis effects (``apply_synthesis_output_effects``).
  /// Getters/setters allow per-call overrides without rebuilding the engine.
  bool normalize_audio() const;
  void set_normalize_audio(bool on);
  float output_volume() const;
  void set_output_volume(float volume);

  static constexpr int kSampleRateHz = 24000;

  /// Text → IPA (MoonshineG2P) → Piper phoneme ids → ONNX → mono float waveform
  /// at ``kSampleRateHz``.
  std::vector<float> synthesize(std::string_view text);

  /// Like ``synthesize`` but starts from an existing IPA phoneme string
  /// (the same format ``MoonshineG2P::text_to_ipa`` produces), skipping G2P.
  /// The IPA is normalized/coerced to this model's phoneme inventory before
  /// running the ONNX vocoder.
  std::vector<float> synthesize_from_ipa(std::string_view ipa);

  /// Run ONNX on an existing Piper phoneme-id sequence (same layout as
  /// ``piper.phoneme_ids.phonemes_to_ids``), then apply ``normalize_audio`` /
  /// ``output_volume`` (via ``apply_synthesis_output_effects``) and resample to
  /// ``kSampleRateHz``. For parity with ``speak.py``
  /// ``--piper-inference-backend onnxruntime`` when *ids* match Piper’s eSpeak
  /// ids.
  std::vector<float> synthesize_phoneme_ids(
      const std::vector<int64_t>& phoneme_ids);

  /// Whether this voice ships the two stages streaming needs, so the generator
  /// can be asked for a range of frames instead of a whole utterance.
  ///
  /// False for a voice that only has its whole-utterance model, which is what
  /// a caller pointing at their own export gets; they stream a sentence at a
  /// time instead. See ``scripts/split-piper-stages.py``.
  bool supports_slicing() const;

  /// Latent frames per second, for turning a chunk length into a frame count.
  int frames_per_second() const;

  /// Run the body over ``text`` and keep the latent for the decodes that will
  /// consume slices of it.
  ///
  /// Returns the number of frames, or 0 when this utterance cannot be sliced
  /// and the caller should synthesize it whole instead.
  int analyze(std::string_view text);

  /// Decode frames ``[first, last)`` of the utterance ``analyze`` last saw,
  /// resampled to ``kSampleRateHz``.
  ///
  /// Padding either side is decoded and dropped, so the result is what the
  /// same range of a whole render holds and successive chunks join without a
  /// crossfade.
  std::vector<float> decode_analyzed(int first, int last);

 private:
  struct Impl;
  std::unique_ptr<Impl> impl_;
};

/// Default Piper model + ``*.onnx.json`` paths relative to ``g2p_root`` (under
/// ``<data_subdir>/piper-voices/``). If ``onnx_model_stem`` is non-empty
/// (basename or stem), it selects that voice instead of the table default (same
/// rules as ``PiperTTSOptions::onnx_model``).
///
/// A voice ships either as a split ORT pair or as a single ``.ort``, so the
/// model side is a list; see ``piper_voice_model_filenames``. The config keeps
/// its
/// ``.onnx.json`` name in both cases.
bool piper_default_model_bundle_relative_paths(
    std::string_view lang_cli, const MoonshineG2POptions& opt,
    std::vector<std::string>* model_relpaths_out,
    std::string* onnx_json_relpath_out, std::string_view onnx_model_stem = {});

/// Piper voice stems (no extension) with availability, same resolution as
/// ``PiperTTS``: a voice counts as present when its split ORT pair, its single
/// ``.ort``, or its original ``.onnx`` is on disk, or when ``piper/onnx`` is
/// supplied in memory. Known voices are the language default plus every voice
/// found under the resolved voices directory (union, sorted).
std::vector<std::pair<std::string, bool>> piper_list_voices_with_availability(
    const PiperTTSOptions& opt);

}  // namespace moonshine_tts

#endif  // MOONSHINE_TTS_PIPER_TTS_H
