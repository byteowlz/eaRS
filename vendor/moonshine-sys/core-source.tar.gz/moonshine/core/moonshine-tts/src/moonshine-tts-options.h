#ifndef MOONSHINE_TTS_MOONSHINE_TTS_OPTIONS_H
#define MOONSHINE_TTS_MOONSHINE_TTS_OPTIONS_H

#include <filesystem>
#include <optional>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

#include "file-information.h"
#include "moonshine-g2p-options.h"

namespace moonshine_tts {

using MoonshineTTSFileInformation = FileInformation;

/// Canonical keys for TTS asset paths (relative to ``g2p_options.g2p_root``
/// unless paths are absolute). When ``g2p_root`` is empty, ``MoonshineTTS``
/// uses the process current working directory as the root.
///
/// Every model key below names a ``.ort``. Moonshine loads ORT-format models
/// only: the wasm and mobile runtimes are minimal ONNX Runtime builds with no
/// ONNX parser compiled in, so a ``.onnx`` cannot be read there at all.
/// Anchor for the Kokoro model, naming the voice rather than a file that has
/// to exist. Kokoro ships as the split pair below, and this key still selects
/// it: the engine derives both halves from whatever path or directory the
/// caller points this at. A single ``.ort`` at this exact path is also loaded,
/// which is what a caller passing their own model gets.
inline constexpr std::string_view kTtsKokoroModelKey = "kokoro/model.ort";
/// The fused Kokoro graph, carrying no weight data. See split-weights.h.
inline constexpr std::string_view kTtsKokoroSplitModelKey =
    "kokoro/model.model.ort";
/// The int8 Kokoro weights plus their dequantize chains, run once at load.
inline constexpr std::string_view kTtsKokoroSplitWeightsKey =
    "kokoro/model.weights.ort";
/// Kokoro cut in two, so streaming can decode a slice at a time.
///
/// The prosody stage turns phonemes into frame-rate features and runs once per
/// utterance; the decoder turns a range of those frames into audio and runs
/// once per chunk. Each half is weight-split the same way the whole graph is,
/// so there are four files. Together they are the same size as the single pair
/// and render identical audio; when they are absent the engine falls back to
/// the whole-utterance model above.
inline constexpr std::string_view kTtsKokoroProsodyModelKey =
    "kokoro/prosody.model.ort";
inline constexpr std::string_view kTtsKokoroProsodyWeightsKey =
    "kokoro/prosody.weights.ort";
inline constexpr std::string_view kTtsKokoroDecoderModelKey =
    "kokoro/decoder.model.ort";
inline constexpr std::string_view kTtsKokoroDecoderWeightsKey =
    "kokoro/decoder.weights.ort";
inline constexpr std::string_view kTtsKokoroConfigJsonKey =
    "kokoro/config.json";
/// Optional explicit Piper model, in ORT format.
///
/// The key name predates the move to ORT and is kept so existing callers keep
/// working; the bytes or path it carries must be a ``.ort``.
inline constexpr std::string_view kTtsPiperOnnxKey = "piper/onnx";
/// Optional Piper model config when it is not beside the model file. Piper
/// names these ``<voice>.onnx.json`` upstream and we keep that name whatever
/// form the model itself ships in.
inline constexpr std::string_view kTtsPiperOnnxJsonKey = "piper/onnx.json";
/// Optional Piper voice directory when ``kTtsPiperOnnxKey`` is unset. Voices
/// in it are ``<stem>.ort`` or the split ``<stem>.model.ort`` plus
/// ``<stem>.weights.ort`` pair.
inline constexpr std::string_view kTtsPiperVoicesKey = "piper/voices";
/// Optional directory of ``*.onnx.json`` files parallel to
/// ``kTtsPiperVoicesKey`` (same basename rules).
inline constexpr std::string_view kTtsPiperVoicesJsonKey = "piper/voices_json";

/// ZipVoice zero-shot voice-cloning model assets. The fm_decoder may be the
/// ``ai.zipvoice`` custom-op (Swoosh/GluGate/…) rewrite, whose ops are
/// compiled into the library.
inline constexpr std::string_view kTtsZipVoiceTextEncoderKey =
    "zipvoice/text_encoder.ort";
inline constexpr std::string_view kTtsZipVoiceFmDecoderKey =
    "zipvoice/fm_decoder.ort";
inline constexpr std::string_view kTtsZipVoiceVocoderKey =
    "zipvoice/vocoder.ort";
inline constexpr std::string_view kTtsZipVoiceTokensKey = "zipvoice/tokens.txt";
inline constexpr std::string_view kTtsZipVoiceModelJsonKey =
    "zipvoice/model.json";
/// Optional user-supplied reference clip as raw little-endian float32 mono PCM
/// (used when ``voice`` is bare ``zipvoice`` with no built-in id). Sample rate
/// comes from ``zipvoice_clone_sample_rate``.
inline constexpr std::string_view kTtsZipVoiceCloneAudioKey =
    "zipvoice/clone_audio";

/// Shared configuration for ``MoonshineTTS`` (Kokoro and Piper file paths, G2P,
/// ORT, CLI-oriented fields). Vocoder assets use ``files`` (same pattern as
/// ``MoonshineG2POptions::files``). The **language** is passed to
/// ``MoonshineTTS``'s constructor.
struct MoonshineTTSOptions {
  MoonshineTTSOptions();

  std::vector<MoonshineTTSFileInformation> file_information{};
  /// Kokoro voice id (e.g. ``af_heart``) or Piper ONNX stem/basename when using
  /// Piper. Prefix with ``kokoro_`` or ``piper_`` (case-insensitive) to select
  /// the vocoder; the prefix is stripped for asset resolution (e.g.
  /// ``kokoro_af_heart`` → Kokoro voice ``af_heart``).
  std::string voice{};
  double speed = 1.0;
  std::vector<std::string> ort_provider_names{};
  std::string coreml_cache_dir{};
  MoonshineG2POptions g2p_options{};
  FileInformationMap files{};
  /// ``kokoro``, ``piper``, or ``auto`` (pick Kokoro when
  /// ``kokoro_tts_lang_supported(language, g2p_options)``). Normally derived
  /// from the ``voice`` prefix; remains ``auto`` when ``voice`` has no engine
  /// prefix.
  std::string vocoder_engine = "auto";
  /// Peak-normalize the waveform produced by ``MoonshineTTS::synthesize``
  /// (Kokoro or Piper) before applying
  /// ``output_volume`` and clipping. Matches ``piper-tts``
  /// ``SynthesisConfig.normalize_audio`` semantics.
  bool normalize_audio = true;
  /// Linear gain applied after ``normalize_audio`` and before clipping to
  /// ``[-1, 1]``. Matches ``piper-tts`` ``SynthesisConfig.volume`` semantics.
  float output_volume = 1.F;
  std::optional<float> piper_noise_scale_override{};
  std::optional<float> piper_noise_w_override{};

  /// How `MoonshineTTS::create_stream` cuts an utterance into audio chunks.
  ///
  /// Only Kokoro, and only where its prosody/decoder stages are installed, can
  /// cut inside a sentence; every other configuration streams a sentence at a
  /// time and ignores these. Defaults come from `ChunkPolicyOptions`, which
  /// documents what each one trades away.
  ///
  /// `stream_growth` is the one worth understanding: chunks get longer as an
  /// utterance goes on, because only the first chunk delays playback while
  /// short chunks are what make the decoder's normalisation drift. Setting it
  /// to 1 gives a uniform grid.
  float stream_first_chunk_seconds = 0.6F;
  float stream_tolerance_seconds = 0.2F;
  float stream_crossfade_seconds = 0.025F;
  float stream_growth = 2.0F;

  /// ZipVoice controls (used only when the ``zipvoice`` vocoder is selected).
  /// ``num_step`` <= 0 and
  /// ``guidance_scale`` < 0 select the per-model default. ``clone_transcript``
  /// describes a caller-supplied ``zipvoice/clone_audio`` clip;
  /// ``clone_sample_rate`` is its sample rate.
  std::string zipvoice_clone_transcript{};
  int zipvoice_clone_sample_rate = 24000;
  bool zipvoice_distill = true;
  int zipvoice_num_step = 0;
  float zipvoice_guidance_scale = -1.F;
  float zipvoice_t_shift = 0.5F;

  /// Default WAV path for CLI-style tooling (``-o`` / ``output`` in
  /// ``parse_options``).
  std::filesystem::path output_path = "out.wav";

  /// Relative or absolute path from ``files`` for key *k*, else
  /// ``std::filesystem::path(k)``.
  std::filesystem::path tts_relative_path(std::string_view canonical_key) const;

  // Whether to log profiling information to the console.
  bool log_profiling = false;

  /// Parses ``key=value``-style entries. G2P-specific keys are forwarded to
  /// ``g2p_options``.
  ///
  /// If ``cli_language`` is null and an entry names ``lang`` or ``language``,
  /// throws. If non-null, those keys write into ``*cli_language`` and set
  /// ``*language_was_set`` when provided.
  ///
  /// ``model_root`` / ``path_root`` / ``tts_root`` / ``g2p_root`` set
  /// ``g2p_options.g2p_root``. If none are set, the cwd is used as the asset
  /// root when constructing ``MoonshineTTS``. Piper file keys: ``piper_onnx``,
  /// ``piper_onnx_json``, ``piper_voices_dir``, ``piper_voices_json_dir``
  /// (hyphenated CLI flags are accepted). Other keys forward to
  /// ``g2p_options``.
  /// ``normalize_audio`` / ``output_volume`` keys (legacy aliases
  /// ``piper_normalize_audio`` /
  /// ``piper_output_volume``) configure the shared post-synthesis effects step.
  /// ``engine`` / ``vocoder_engine`` entries are accepted for compatibility but
  /// ignored (engine is encoded in ``voice``).
  void parse_options(
      const std::vector<std::pair<std::string, std::string>>& options,
      std::string* cli_language = nullptr, bool* language_was_set = nullptr);

  /// If ``voice`` starts with ``kokoro_`` or ``piper_`` (ASCII
  /// case-insensitive), sets ``vocoder_engine`` accordingly and removes that
  /// prefix from ``voice`` (after trim). Idempotent when there is no matching
  /// prefix.
  void apply_voice_engine_prefix();
};

/// Shared post-synthesis effects step for Kokoro and Piper output. Mirrors
/// ``piper-tts``'s
/// ``SynthesisConfig`` behaviour: optional peak normalization, gain, then clip
/// to ``[-1, 1]``.
void apply_synthesis_output_effects(std::vector<float>& audio,
                                    bool normalize_audio, float volume);

}  // namespace moonshine_tts

#endif  // MOONSHINE_TTS_MOONSHINE_TTS_OPTIONS_H
