#include "piper-tts.h"

#include <nlohmann/json.h>
#include <onnxruntime_cxx_api.h>

#include "debug-utils.h"
#include "g2p-path.h"
#include "ipa-postprocess.h"
#include "moonshine-g2p.h"
#include "moonshine-tts-options.h"
#include "ort-session-options.h"
#include "ort-utils-cxx.h"
#include "piper-voice-catalog.h"
#include "piper-voice-levels.h"
#include "split-weights.h"
#include "utf8-utils.h"

extern "C" {
#include <utf8proc.h>
}

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <map>
#include <set>
#include <stdexcept>
#include <unordered_map>
#include <unordered_set>

namespace moonshine_tts {

namespace {

/// Latent frames decoded either side of a chunk and then discarded.
///
/// The generator's receptive field reaches back a little way, so a slice
/// decoded on its own starts from the wrong state. Measured against the whole
/// render, 8 frames leaves 3.9e-4 relative error at the join and 16 leaves
/// 1.1e-6, which is inaudible; the cost is a fixed 32 frames of extra decode
/// per chunk, well under a millisecond of work.
constexpr int kSlicePadFrames = 16;

std::string normalize_lang_key(std::string_view raw) {
  std::string s = trim_ascii_ws_copy(raw);
  for (char& c : s) {
    if (c == ' ') {
      c = '_';
    } else if (c == '-') {
      c = '_';
    } else if (c >= 'A' && c <= 'Z') {
      c = static_cast<char>(c - 'A' + 'a');
    }
  }
  return s;
}

bool py_isspace_utf8_ch(std::string_view ch) {
  if (ch.empty()) {
    return false;
  }
  std::string tmp(ch);
  char32_t cp = 0;
  size_t adv = 0;
  if (!utf8_decode_at(tmp, 0, cp, adv) || adv != tmp.size()) {
    return false;
  }
  if (cp < 128) {
    return std::isspace(static_cast<unsigned char>(cp)) != 0;
  }
  const auto cat = utf8proc_category(static_cast<utf8proc_int32_t>(cp));
  return cat == UTF8PROC_CATEGORY_ZS || cat == UTF8PROC_CATEGORY_ZL ||
         cat == UTF8PROC_CATEGORY_ZP;
}

struct PiperLangRow {
  const char* g2p_dialect;
  const char* data_subdir;
  const char* default_onnx;
};

const PiperLangRow* lookup_piper_lang_row(std::string_view k) {
  // Keys are mostly ``ll`` or ``ll_rr`` (underscore). Canonical API tags like
  // ``hi-in`` / ``de-de`` normalize to ``hi_in`` / ``de_de``; collapse those to
  // the primary map key when equivalent.
  static const std::unordered_map<std::string, PiperLangRow> m{
      {"en_us", {"en_us", "en_us", "en_US-lessac-medium.onnx"}},
      {"en-us", {"en_us", "en_us", "en_US-lessac-medium.onnx"}},
      {"en", {"en_us", "en_us", "en_US-lessac-medium.onnx"}},
      {"en_gb", {"en_gb", "en_gb", "en_GB-cori-medium.onnx"}},
      {"en-gb", {"en_gb", "en_gb", "en_GB-cori-medium.onnx"}},
      {"es", {"es-MX", "es_mx", "es_MX-ald-medium.onnx"}},
      {"es_mx", {"es-MX", "es_mx", "es_MX-ald-medium.onnx"}},
      {"es_es", {"es-ES", "es_es", "es_ES-davefx-medium.onnx"}},
      {"es_ar", {"es-AR", "es_ar", "es_AR-daniela-high.onnx"}},
      {"fr", {"fr-FR", "fr", "fr_FR-siwis-medium.onnx"}},
      {"hi", {"hi", "hi", "hi_IN-pratham-medium.onnx"}},
      {"it", {"it-IT", "it", "it_IT-paola-medium.onnx"}},
      {"pt_br", {"pt_br", "pt_br", "pt_BR-cadu-medium.onnx"}},
      {"pt-br", {"pt_br", "pt_br", "pt_BR-cadu-medium.onnx"}},
      {"pt", {"pt_br", "pt_br", "pt_BR-cadu-medium.onnx"}},
      {"pt_pt", {"pt_pt", "pt_pt", "pt_PT-tugão-medium.onnx"}},
      {"pt-pt", {"pt_pt", "pt_pt", "pt_PT-tugão-medium.onnx"}},
      {"zh", {"zh", "zh_hans", "zh_CN-huayan-medium.onnx"}},
      {"zh_hans", {"zh", "zh_hans", "zh_CN-huayan-medium.onnx"}},
      {"zh_cn", {"zh", "zh_hans", "zh_CN-huayan-medium.onnx"}},
      {"zt", {"zh", "zh_hans", "zh_CN-huayan-medium.onnx"}},
      {"ar_msa", {"ar", "ar_msa", "ar_JO-kareem-medium.onnx"}},
      {"ar", {"ar", "ar_msa", "ar_JO-kareem-medium.onnx"}},
      {"de", {"de-DE", "de", "de_DE-thorsten-medium.onnx"}},
      {"nl", {"nl-NL", "nl", "nl_NL-mls-medium.onnx"}},
      {"ru", {"ru-RU", "ru", "ru_RU-denis-medium.onnx"}},
      {"tr", {"tr-TR", "tr", "tr_TR-dfki-medium.onnx"}},
      {"uk", {"uk-UA", "uk", "uk_UA-ukrainian_tts-medium.onnx"}},
      {"vi", {"vi-VN", "vi", "vi_VN-vais1000-medium.onnx"}},
      {"ko", {"ko", "ko", "ko_KR-melotts-medium.onnx"}},
      {"ko_kr", {"ko", "ko", "ko_KR-melotts-medium.onnx"}},
      {"korean", {"ko", "ko", "ko_KR-melotts-medium.onnx"}},
  };
  const std::string key = normalize_lang_key(k);
  if (const auto it = m.find(key); it != m.end()) {
    return &it->second;
  }
  static const std::unordered_map<std::string, std::string>
      kBcp47UnderscoreToPrimary{
          {"de_de", "de"}, {"fr_fr", "fr"}, {"hi_in", "hi"},
          {"it_it", "it"}, {"nl_nl", "nl"}, {"ru_ru", "ru"},
          {"vi_vn", "vi"}, {"uk_ua", "uk"}, {"tr_tr", "tr"},
      };
  if (const auto c = kBcp47UnderscoreToPrimary.find(key);
      c != kBcp47UnderscoreToPrimary.end()) {
    if (const auto it2 = m.find(c->second); it2 != m.end()) {
      return &it2->second;
    }
  }
  return nullptr;
}

std::string piper_ipa_norm_lang_key(const std::string& lk,
                                    std::string_view data_subdir) {
  if (data_subdir == "es_es") {
    return "es_es";
  }
  if (data_subdir == "es_mx") {
    return "es_mx";
  }
  if (data_subdir == "es_ar") {
    return "es_ar";
  }
  return normalize_lang_key(lk);
}

void resolve_piper_lang(const std::string& lk, const MoonshineG2POptions& opt,
                        std::string& g2p_dialect, std::string& data_subdir,
                        std::string& default_onnx) {
  const std::string k = normalize_lang_key(lk);
  if (k == "ja" || k == "jp" || k == "ja_jp") {
    throw std::runtime_error(
        "PiperTTS: Japanese is not available as a Piper ONNX bundle here; use "
        "MoonshineTTS (Kokoro).");
  }
  const std::string norm = normalize_rule_based_dialect_cli_key(lk);
  if (!norm.empty() &&
      dialect_resolves_to_spanish_rules(norm, opt.spanish_narrow_obstruents)) {
    g2p_dialect = norm;
    if (norm.rfind("es-ES", 0) == 0) {
      data_subdir = "es_es";
      default_onnx = "es_ES-davefx-medium.onnx";
    } else if (norm == "es-AR") {
      data_subdir = "es_ar";
      default_onnx = "es_AR-daniela-high.onnx";
    } else {
      data_subdir = "es_mx";
      default_onnx = "es_MX-ald-medium.onnx";
    }
    return;
  }
  const PiperLangRow* row = lookup_piper_lang_row(k);
  if (row == nullptr) {
    throw std::runtime_error("PiperTTS: unsupported --lang key \"" + lk + "\"");
  }
  g2p_dialect = row->g2p_dialect;
  data_subdir = row->data_subdir;
  default_onnx = row->default_onnx;
}

/// Strips the extension a caller may have appended to a voice name.
///
/// Voices are identified by stem, but callers have long been allowed to pass
/// ``foo.onnx``, and now also name the ORT files directly.
std::string piper_voice_stem(std::string_view name) {
  std::string s(trim_ascii_ws_copy(name));
  const auto strip = [&s](std::initializer_list<std::string_view> suffixes) {
    for (const std::string_view suffix : suffixes) {
      if (s.size() > suffix.size() &&
          s.compare(s.size() - suffix.size(), suffix.size(), suffix) == 0) {
        s.resize(s.size() - suffix.size());
        return;
      }
    }
  };
  strip({".weights.ort", ".model.ort", ".onnx", ".ort"});
  // A voice ships as two stages, so both of those names lead back to it.
  strip({".upstream", ".generator"});
  return s;
}

/// The file to open for a voice, or an empty path when none is on disk.
///
/// A voice can be present in either of two forms, preferred in this order: a
/// split ORT pair (fastest to load, see ``load_split_weight_sessions``) or a
/// single ``.ort``. Only the split pair needs both files, so it is checked as
/// a pair.
std::filesystem::path piper_voice_model_path(
    const std::filesystem::path& voices_dir, const std::string& stem) {
  const std::filesystem::path split_model = voices_dir / (stem + ".model.ort");
  if (std::filesystem::is_regular_file(split_model) &&
      std::filesystem::is_regular_file(voices_dir / (stem + ".weights.ort"))) {
    return split_model;
  }
  const std::filesystem::path single = voices_dir / (stem + ".ort");
  if (std::filesystem::is_regular_file(single)) {
    return single;
  }
  return {};
}

/// Whether both stages of a voice are on disk, in either ORT form.
bool piper_voice_stages_present(const std::filesystem::path& voices_dir,
                                const std::string& stem) {
  for (const std::string_view stage : {".upstream", ".generator"}) {
    const std::string base = stem + std::string(stage);
    const bool split =
        std::filesystem::is_regular_file(voices_dir / (base + ".model.ort")) &&
        std::filesystem::is_regular_file(voices_dir / (base + ".weights.ort"));
    if (!split &&
        !std::filesystem::is_regular_file(voices_dir / (base + ".ort"))) {
      return false;
    }
  }
  return true;
}

bool piper_voice_model_present(const std::filesystem::path& voices_dir,
                               const std::string& stem) {
  return piper_voice_stages_present(voices_dir, stem) ||
         !piper_voice_model_path(voices_dir, stem).empty();
}

/// Voice stems present in a directory, in any of the three model forms.
std::vector<std::string> piper_voice_stems_on_disk(
    const std::filesystem::path& voices_dir) {
  std::set<std::string> stems;
  if (!std::filesystem::is_directory(voices_dir)) {
    return {};
  }
  for (const auto& ent : std::filesystem::directory_iterator(voices_dir)) {
    if (!ent.is_regular_file()) {
      continue;
    }
    const std::string name = ent.path().filename().string();
    const std::string stem = piper_voice_stem(name);
    if (stem != name && piper_voice_model_present(voices_dir, stem)) {
      stems.insert(stem);
    }
  }
  return {stems.begin(), stems.end()};
}

/// Resolves a voice request to the nominal ``<stem>.onnx`` path in
/// *voices_dir*.
///
/// The returned path is an anchor rather than a file to open: the ``.onnx`` may
/// not exist, since a voice can ship as ORT instead. Everything downstream
/// derives from it, including the ``<stem>.onnx.json`` config (whose name keeps
/// the ``.onnx`` regardless of model form) and the split-pair file names.
std::filesystem::path pick_onnx_path(const std::filesystem::path& voices_dir,
                                     std::string_view requested,
                                     std::string_view default_basename) {
  if (!std::filesystem::is_directory(voices_dir)) {
    throw std::runtime_error("PiperTTS: voices_dir is not a directory: " +
                             voices_dir.string());
  }
  const auto anchor = [&](const std::string& stem) {
    return voices_dir / (stem + ".onnx");
  };
  if (!requested.empty()) {
    const std::string stem = piper_voice_stem(requested);
    if (piper_voice_model_present(voices_dir, stem)) {
      return anchor(stem);
    }
    LOGF("Requested Piper voice '%s' not found in '%s', falling back to '%s'",
         std::string(requested).c_str(), voices_dir.c_str(),
         std::string(default_basename).c_str());
  }
  const std::string default_stem = piper_voice_stem(default_basename);
  if (piper_voice_model_present(voices_dir, default_stem)) {
    return anchor(default_stem);
  }
  const std::vector<std::string> stems = piper_voice_stems_on_disk(voices_dir);
  if (!requested.empty()) {
    std::string available;
    for (const std::string& stem : stems) {
      if (!available.empty()) available += ", ";
      available += stem;
    }
    if (available.empty()) {
      LOG("  Available Piper voices: (none)");
    } else {
      LOGF("  Available Piper voices: %s", available.c_str());
    }
  }
  if (stems.empty()) {
    throw std::runtime_error("PiperTTS: no voice model files in " +
                             voices_dir.string());
  }
  return anchor(stems.front());
}

/// Piper pairs ``foo.onnx`` with ``foo.onnx.json``. If ``json_dir`` is empty,
/// that file sits beside ``onnx_path``.
std::filesystem::path piper_model_json_path_for_onnx(
    const std::filesystem::path& onnx_path,
    const std::filesystem::path& json_dir) {
  if (!json_dir.empty()) {
    return json_dir / (onnx_path.filename().string() + ".json");
  }
  std::filesystem::path p = onnx_path;
  p.replace_extension(".onnx.json");
  return p;
}

void append_phoneme_ids(
    const std::unordered_map<std::string, std::vector<int64_t>>& id_map,
    const std::string& key, std::vector<int64_t>& ids) {
  const auto it = id_map.find(key);
  if (it == id_map.end()) {
    return;
  }
  for (int64_t v : it->second) {
    ids.push_back(v);
  }
}

std::vector<int64_t> ipa_utf8_to_piper_ids(
    const std::string& ipa_nfc,
    const std::unordered_map<std::string, std::vector<int64_t>>& id_map) {
  std::string ipa = ipa_nfc;
  repair_ascii_c_combining_cedilla_to_ccedilla_utf8(ipa);
  std::vector<int64_t> ids;
  append_phoneme_ids(id_map, "^", ids);
  append_phoneme_ids(id_map, "_", ids);
  for (const std::string& ch : utf8_split_codepoints(ipa)) {
    if (py_isspace_utf8_ch(ch)) {
      append_phoneme_ids(id_map, " ", ids);
      continue;
    }
    if (id_map.count(ch) != 0) {
      append_phoneme_ids(id_map, ch, ids);
      append_phoneme_ids(id_map, "_", ids);
    }
  }
  append_phoneme_ids(id_map, "$", ids);
  return ids;
}

std::vector<float> resample_linear(const std::vector<float>& x, int src_sr,
                                   int dst_sr) {
  if (src_sr == dst_sr || x.empty()) {
    return x;
  }
  const double duration =
      static_cast<double>(x.size() - 1) / static_cast<double>(src_sr);
  const size_t n_out = std::max<size_t>(
      2, static_cast<size_t>(std::llround(duration * dst_sr)) + 1);
  std::vector<float> y(n_out);
  for (size_t i = 0; i < n_out; ++i) {
    const double t = (n_out <= 1) ? 0.0
                                  : (static_cast<double>(i) * duration /
                                     static_cast<double>(n_out - 1));
    const double fidx = t * static_cast<double>(src_sr);
    const size_t i0 = static_cast<size_t>(std::floor(fidx));
    const size_t i1 = std::min(i0 + 1, x.size() - 1);
    const double frac = fidx - static_cast<double>(i0);
    y[i] = static_cast<float>(x[i0] * (1.0 - frac) + x[i1] * frac);
  }
  return y;
}

void load_piper_onnx_json(
    const std::filesystem::path& json_path,
    std::unordered_map<std::string, std::vector<int64_t>>& phoneme_id_map,
    int& native_sample_rate, float& noise_scale, float& length_scale_default,
    float& noise_w, int& num_speakers) {
  std::ifstream jf(json_path);
  if (!jf) {
    throw std::runtime_error("PiperTTS: cannot open config " +
                             json_path.string());
  }
  nlohmann::json j;
  jf >> j;
  if (!j.contains("phoneme_id_map") || !j["phoneme_id_map"].is_object()) {
    throw std::runtime_error("PiperTTS: phoneme_id_map missing in " +
                             json_path.string());
  }
  phoneme_id_map.clear();
  for (auto it = j["phoneme_id_map"].begin(); it != j["phoneme_id_map"].end();
       ++it) {
    std::vector<int64_t> seq;
    if (it.value().is_array()) {
      for (const auto& el : it.value()) {
        seq.push_back(el.get<int64_t>());
      }
    }
    phoneme_id_map[it.key()] = std::move(seq);
  }
  native_sample_rate = 22050;
  noise_scale = 0.667F;
  length_scale_default = 1.F;
  noise_w = 0.8F;
  num_speakers = 1;
  if (j.contains("audio") && j["audio"].is_object() &&
      j["audio"].contains("sample_rate")) {
    native_sample_rate = j["audio"]["sample_rate"].get<int>();
  }
  if (j.contains("inference") && j["inference"].is_object()) {
    const auto& inf = j["inference"];
    if (inf.contains("noise_scale")) {
      noise_scale = inf["noise_scale"].get<float>();
    }
    if (inf.contains("length_scale")) {
      length_scale_default = inf["length_scale"].get<float>();
    }
    if (inf.contains("noise_w")) {
      noise_w = inf["noise_w"].get<float>();
    }
  }
  if (j.contains("num_speakers")) {
    num_speakers = j["num_speakers"].get<int>();
  }
}

void load_piper_onnx_json_bytes(
    const char* data, size_t size, std::string_view ctx,
    std::unordered_map<std::string, std::vector<int64_t>>& phoneme_id_map,
    int& native_sample_rate, float& noise_scale, float& length_scale_default,
    float& noise_w, int& num_speakers) {
  nlohmann::json j = nlohmann::json::parse(data, data + size);
  if (!j.contains("phoneme_id_map") || !j["phoneme_id_map"].is_object()) {
    throw std::runtime_error(
        "PiperTTS: phoneme_id_map missing in piper config (" +
        std::string(ctx) + ")");
  }
  phoneme_id_map.clear();
  for (auto it = j["phoneme_id_map"].begin(); it != j["phoneme_id_map"].end();
       ++it) {
    std::vector<int64_t> seq;
    if (it.value().is_array()) {
      for (const auto& el : it.value()) {
        seq.push_back(el.get<int64_t>());
      }
    }
    phoneme_id_map[it.key()] = std::move(seq);
  }
  native_sample_rate = 22050;
  noise_scale = 0.667F;
  length_scale_default = 1.F;
  noise_w = 0.8F;
  num_speakers = 1;
  if (j.contains("audio") && j["audio"].is_object() &&
      j["audio"].contains("sample_rate")) {
    native_sample_rate = j["audio"]["sample_rate"].get<int>();
  }
  if (j.contains("inference") && j["inference"].is_object()) {
    const auto& inf = j["inference"];
    if (inf.contains("noise_scale")) {
      noise_scale = inf["noise_scale"].get<float>();
    }
    if (inf.contains("length_scale")) {
      length_scale_default = inf["length_scale"].get<float>();
    }
    if (inf.contains("noise_w")) {
      noise_w = inf["noise_w"].get<float>();
    }
  }
  if (j.contains("num_speakers")) {
    num_speakers = j["num_speakers"].get<int>();
  }
}

}  // namespace

struct PiperTTS::Impl {
  std::filesystem::path voices_dir_;
  std::filesystem::path voices_json_dir_;
  std::filesystem::path onnx_path_;
  std::filesystem::path explicit_onnx_json_path_;
  Ort::Env env_ = make_ort_env(ORT_LOGGING_LEVEL_WARNING, "piper_tts");
  Ort::Session session_{nullptr};
  Ort::MemoryInfo mem_{
      Ort::MemoryInfo::CreateCpu(OrtArenaAllocator, OrtMemTypeDefault)};

  /// Float32 weights supplied to the graph on every inference, for voices that
  /// ship as a split ORT pair. See split-weights.h.
  std::vector<SplitWeight> split_weights_{};

  /// The same voice cut in two, when those files are present: a body that runs
  /// once per utterance and a generator that can be asked for a range of
  /// frames. This is what lets streaming cut below a sentence.
  Ort::Session upstream_session_{nullptr};
  Ort::Session generator_session_{nullptr};
  std::vector<SplitWeight> upstream_weights_{};
  std::vector<SplitWeight> generator_weights_{};
  bool stages_loaded_ = false;
  /// Whether `session_` holds a whole-utterance model. False for a voice that
  /// ships only its stages, which is every voice we publish.
  bool monolith_loaded_ = false;
  /// Audio samples one latent frame is worth, at the voice's native rate.
  int hop_ = 0;

  /// A tensor the body hands the generator.
  struct SeamTensor {
    std::string name;
    std::vector<int64_t> shape;
    std::vector<float> data;
  };
  /// The latent, at one column per frame, and its name in both graphs.
  std::string latent_name_{};
  std::vector<int64_t> latent_shape_{};
  std::vector<float> latent_{};
  /// Whatever else crosses, which for a multi-speaker voice is the speaker
  /// embedding: one column for the utterance, handed to every chunk unchanged.
  std::vector<SeamTensor> conditioning_{};
  /// Where the utterance's samples land after resampling, worked out once so
  /// every chunk places itself on the grid a whole render would have used.
  size_t total_native_ = 0;
  size_t total_out_ = 0;
  double resample_step_ = 0.0;

  std::unordered_map<std::string, std::vector<int64_t>> phoneme_id_map_{};
  std::unordered_set<std::string> phoneme_map_keys_{};
  std::string piper_ipa_lang_key_{};
  int native_sample_rate_ = 22050;
  float noise_scale_ = 0.667F;
  float length_scale_default_ = 1.F;
  float noise_w_ = 0.8F;
  int num_speakers_ = 1;

  double speed_ = 1.0;
  MoonshineG2POptions g2p_opt_{};
  std::unique_ptr<MoonshineG2P> g2p_{};
  std::string g2p_dialect_{};
  std::string data_subdir_{};
  std::string default_onnx_{};
  std::string onnx_basename_request_{};
  bool user_voices_dir_ = false;
  bool explicit_onnx_file_ = false;
  std::vector<std::string> ort_provider_names_{};
  std::string coreml_cache_dir_{};
  bool normalize_audio_ = true;
  float output_volume_ = 1.F;
  std::optional<float> noise_scale_override_{};
  std::optional<float> noise_w_override_{};
  FileInformationMap tts_asset_files_{};

  ~Impl() {
    for (auto& e : tts_asset_files_.entries) {
      e.second.free();
    }
  }

  std::vector<float> run_ort_from_phoneme_ids(const std::vector<int64_t>& ids) {
    if (ids.size() < 3) {
      throw std::runtime_error("PiperTTS: phoneme id sequence too short");
    }
    std::vector<float> wave =
        monolith_loaded_ ? run_whole_model(ids) : run_stages_whole(ids);
    apply_synthesis_output_effects(wave, normalize_audio_, output_volume_);
    if (native_sample_rate_ != PiperTTS::kSampleRateHz) {
      wave =
          resample_linear(wave, native_sample_rate_, PiperTTS::kSampleRateHz);
    }
    return wave;
  }

  /// Native-rate audio for a whole utterance, from the single-file model.
  std::vector<float> run_whole_model(const std::vector<int64_t>& ids) {
    const int64_t ntok = static_cast<int64_t>(ids.size());
    int64_t input_len = ntok;
    const std::array<int64_t, 2> shape_in{1, ntok};
    const std::array<int64_t, 1> shape_len{1};
    double sp = speed_;
    if (sp < 0.25) {
      sp = 0.25;
    }
    if (sp > 4.0) {
      sp = 4.0;
    }
    const float length_scale = length_scale_default_ / static_cast<float>(sp);
    float ns = noise_scale_;
    float nw = noise_w_;
    if (noise_scale_override_.has_value()) {
      ns = noise_scale_override_.value();
    }
    if (noise_w_override_.has_value()) {
      nw = noise_w_override_.value();
    }
    std::array<float, 3> scales{ns, length_scale, nw};
    const std::array<int64_t, 1> shape_scales{3};

    std::vector<Ort::Value> inputs;
    inputs.push_back(Ort::Value::CreateTensor<int64_t>(
        mem_, const_cast<int64_t*>(ids.data()), ids.size(), shape_in.data(),
        shape_in.size()));
    inputs.push_back(Ort::Value::CreateTensor<int64_t>(
        mem_, &input_len, 1, shape_len.data(), shape_len.size()));
    inputs.push_back(Ort::Value::CreateTensor<float>(
        mem_, scales.data(), scales.size(), shape_scales.data(),
        shape_scales.size()));

    std::vector<const char*> in_names{"input", "input_lengths", "scales"};
    int64_t sid = 0;
    if (num_speakers_ > 1) {
      inputs.push_back(Ort::Value::CreateTensor<int64_t>(
          mem_, &sid, 1, shape_len.data(), shape_len.size()));
      in_names.push_back("sid");
    }

    // Split-weights voices keep their weights out of the model, so pass them
    // alongside the text inputs.
    append_split_weight_inputs(split_weights_, mem_, inputs, in_names);

    Ort::RunOptions run_opts{nullptr};
    const char* out_names[] = {"output"};
    auto outputs = session_.Run(run_opts, in_names.data(), inputs.data(),
                                inputs.size(), out_names, 1);
    const Ort::Value& outv = outputs[0];
    const auto ti = outv.GetTensorTypeAndShapeInfo();
    if (ti.GetElementType() != ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT) {
      throw std::runtime_error("PiperTTS: ONNX output is not float32");
    }
    const size_t n_el = ti.GetElementCount();
    const float* ptr = outv.GetTensorData<float>();
    return std::vector<float>(ptr, ptr + n_el);
  }

  /// Native-rate audio for a whole utterance, from the two stages.
  ///
  /// The same two runs the monolith did internally, so the samples are the
  /// ones it would have produced and the cost is within a percent or two.
  std::vector<float> run_stages_whole(const std::vector<int64_t>& ids) {
    const int frames = run_upstream(ids);
    if (frames <= 0) {
      return {};
    }
    return run_generator(0, frames);
  }

  /// Loads the split-weights form of a voice if it is present on disk.
  ///
  /// Returns false when the pair is absent, leaving the caller to open the
  /// single-file form. See split-weights.h for why voices ship this way.
  bool load_split_weight_sessions(const Ort::SessionOptions& session_opts) {
    if (onnx_path_.empty()) {
      return false;
    }
    std::filesystem::path model_path = onnx_path_;
    model_path.replace_extension(".model.ort");
    std::filesystem::path weights_path = onnx_path_;
    weights_path.replace_extension(".weights.ort");
    if (!std::filesystem::is_regular_file(model_path) ||
        !std::filesystem::is_regular_file(weights_path)) {
      return false;
    }

    std::vector<SplitWeight> weights =
        run_split_weights_model(env_, weights_path, session_opts);
#ifdef _WIN32
    const std::wstring wmodel = model_path.wstring();
    session_ = Ort::Session(env_, wmodel.c_str(), session_opts);
#else
    const std::string model_u8 = model_path.string();
    session_ = Ort::Session(env_, model_u8.c_str(), session_opts);
#endif
    split_weights_ = std::move(weights);
    return true;
  }

  /// Opens one stage, in whichever of the two ORT forms it was published as.
  bool open_stage(const Ort::SessionOptions& session_opts,
                  const std::string& suffix, Ort::Session& out_session,
                  std::vector<SplitWeight>& out_weights) {
    const std::filesystem::path dir = onnx_path_.parent_path();
    const std::string stem = piper_voice_stem(onnx_path_.filename().string());
    const std::filesystem::path graph = dir / (stem + suffix + ".model.ort");
    const std::filesystem::path weights =
        dir / (stem + suffix + ".weights.ort");
    if (std::filesystem::is_regular_file(graph) &&
        std::filesystem::is_regular_file(weights)) {
      out_weights = run_split_weights_model(env_, weights, session_opts);
#ifdef _WIN32
      const std::wstring wide = graph.wstring();
      out_session = Ort::Session(env_, wide.c_str(), session_opts);
#else
      const std::string utf8 = graph.string();
      out_session = Ort::Session(env_, utf8.c_str(), session_opts);
#endif
      return true;
    }
    const std::filesystem::path single = dir / (stem + suffix + ".ort");
    if (!std::filesystem::is_regular_file(single)) {
      return false;
    }
    out_weights.clear();
#ifdef _WIN32
    const std::wstring wide = single.wstring();
    out_session = Ort::Session(env_, wide.c_str(), session_opts);
#else
    const std::string utf8 = single.string();
    out_session = Ort::Session(env_, utf8.c_str(), session_opts);
#endif
    return true;
  }

  /// Measures what one latent frame is worth in audio samples.
  ///
  /// The generator is a fixed stack of transposed convolutions, so the ratio
  /// is a property of the voice rather than of the utterance, and running a
  /// few frames of silence through it is the cheapest way to read it off. No
  /// Piper config records it.
  int probe_hop(const std::vector<int64_t>& latent_shape) {
    if (latent_shape.size() != 3 || latent_shape[1] <= 0) {
      return 0;
    }
    constexpr int64_t k_probe_frames = 8;
    const std::array<int64_t, 3> probe_shape{1, latent_shape[1],
                                             k_probe_frames};
    std::vector<float> silence(
        static_cast<size_t>(latent_shape[1] * k_probe_frames), 0.F);
    std::vector<Ort::Value> inputs;
    std::vector<const char*> names;
    inputs.push_back(Ort::Value::CreateTensor<float>(
        mem_, silence.data(), silence.size(), probe_shape.data(),
        probe_shape.size()));
    names.push_back(latent_name_.c_str());
    std::vector<std::vector<float>> held;
    held.reserve(conditioning_.size());
    for (SeamTensor& tensor : conditioning_) {
      held.push_back(std::vector<float>(tensor.data.size(), 0.F));
      inputs.push_back(Ort::Value::CreateTensor<float>(
          mem_, held.back().data(), held.back().size(), tensor.shape.data(),
          tensor.shape.size()));
      names.push_back(tensor.name.c_str());
    }
    append_split_weight_inputs(generator_weights_, mem_, inputs, names);
    Ort::RunOptions run_opts{nullptr};
    const char* out_names[] = {"output"};
    auto outputs = generator_session_.Run(run_opts, names.data(), inputs.data(),
                                          inputs.size(), out_names, 1);
    const size_t produced =
        outputs[0].GetTensorTypeAndShapeInfo().GetElementCount();
    return static_cast<int>(produced / static_cast<size_t>(k_probe_frames));
  }

  /// Opens the body/generator pair, if this voice was published with one.
  ///
  /// Optional on purpose: without it the voice still speaks, a sentence at a
  /// time, so nothing here throws.
  void load_stages(const Ort::SessionOptions& session_opts) {
    stages_loaded_ = false;
    latent_name_.clear();
    conditioning_.clear();
    if (onnx_path_.empty()) {
      return;
    }
    if (!open_stage(session_opts, ".upstream", upstream_session_,
                    upstream_weights_)) {
      return;
    }
    if (!open_stage(session_opts, ".generator", generator_session_,
                    generator_weights_)) {
      upstream_session_ = Ort::Session(nullptr);
      upstream_weights_.clear();
      return;
    }

    // Whatever the generator takes that is not one of its weights is what the
    // body hands it. The widest of those is the latent; the rest are constant
    // for the utterance.
    std::unordered_set<std::string> weight_names;
    for (const SplitWeight& weight : generator_weights_) {
      weight_names.insert(weight.name);
    }
    Ort::AllocatorWithDefaultOptions allocator;
    std::vector<SeamTensor> seam;
    for (size_t i = 0; i < generator_session_.GetInputCount(); ++i) {
      Ort::AllocatedStringPtr held =
          generator_session_.GetInputNameAllocated(i, allocator);
      std::string name(held.get());
      if (weight_names.count(name) != 0) {
        continue;
      }
      const Ort::TypeInfo type_info = generator_session_.GetInputTypeInfo(i);
      SeamTensor tensor;
      tensor.name = std::move(name);
      tensor.shape = type_info.GetTensorTypeAndShapeInfo().GetShape();
      seam.push_back(std::move(tensor));
    }
    if (seam.empty()) {
      upstream_session_ = Ort::Session(nullptr);
      generator_session_ = Ort::Session(nullptr);
      return;
    }
    // The latent is the one that grows with the utterance, so it is the one
    // whose last axis is dynamic. A speaker embedding is one column wide
    // however long the utterance is, and so is fully fixed.
    size_t latent = seam.size();
    for (size_t i = 0; i < seam.size(); ++i) {
      if (seam[i].shape.size() == 3 && seam[i].shape[2] < 0) {
        latent = i;
        break;
      }
    }
    if (latent == seam.size()) {
      upstream_session_ = Ort::Session(nullptr);
      generator_session_ = Ort::Session(nullptr);
      return;
    }
    latent_name_ = seam[latent].name;
    for (size_t i = 0; i < seam.size(); ++i) {
      if (i != latent) {
        SeamTensor tensor = seam[i];
        size_t count = 1;
        for (int64_t dim : tensor.shape) {
          count *= static_cast<size_t>(dim > 0 ? dim : 1);
        }
        tensor.data.assign(count, 0.F);
        conditioning_.push_back(std::move(tensor));
      }
    }
    hop_ = probe_hop(seam[latent].shape);
    if (hop_ <= 0) {
      upstream_session_ = Ort::Session(nullptr);
      generator_session_ = Ort::Session(nullptr);
      conditioning_.clear();
      return;
    }
    stages_loaded_ = true;
  }

  void reload_session() {
    static const std::string k_piper_json("piper/onnx.json");
    static const std::string k_piper_onnx("piper/onnx");
    const std::filesystem::path json_disk =
        !explicit_onnx_json_path_.empty()
            ? explicit_onnx_json_path_
            : piper_model_json_path_for_onnx(onnx_path_, voices_json_dir_);

    const auto jit = tts_asset_files_.entries.find(k_piper_json);
    if (jit != tts_asset_files_.entries.end()) {
      FileInformation& jf = jit->second;
      const uint8_t* jb = nullptr;
      size_t jn = 0;
      jf.load(&jb, &jn);
      load_piper_onnx_json_bytes(
          reinterpret_cast<const char*>(jb), jn, k_piper_json, phoneme_id_map_,
          native_sample_rate_, noise_scale_, length_scale_default_, noise_w_,
          num_speakers_);
      jf.free();
    } else {
      if (!std::filesystem::is_regular_file(json_disk)) {
        throw std::runtime_error("PiperTTS: missing config " +
                                 json_disk.string());
      }
      load_piper_onnx_json(json_disk, phoneme_id_map_, native_sample_rate_,
                           noise_scale_, length_scale_default_, noise_w_,
                           num_speakers_);
    }
    phoneme_map_keys_.clear();
    for (const auto& e : phoneme_id_map_) {
      phoneme_map_keys_.insert(e.first);
    }
    Ort::SessionOptions session_opts =
        make_ort_session_options(ort_provider_names_, coreml_cache_dir_);
    split_weights_.clear();
    monolith_loaded_ = false;
    const auto oit = tts_asset_files_.entries.find(k_piper_onnx);
    if (oit == tts_asset_files_.entries.end()) {
      load_stages(session_opts);
      if (stages_loaded_) {
        // The two stages render a whole utterance as readily as a slice of
        // one, and cost the same to run, so a voice published in this form
        // ships no monolithic model for the one-shot path to use.
        session_ = Ort::Session(nullptr);
        return;
      }
      if (load_split_weight_sessions(session_opts)) {
        monolith_loaded_ = true;
        return;
      }
    }
    if (oit != tts_asset_files_.entries.end()) {
      FileInformation& of = oit->second;
      const uint8_t* ob = nullptr;
      size_t on = 0;
      of.load(&ob, &on);
      require_ort_model_bytes(ob, on,
                              "Piper voice supplied as " + k_piper_onnx);
      session_ = Ort::Session(env_, ob, on, session_opts);
      of.free();
    } else {
      // onnx_path_ is only an anchor for the voice name; the file on disk is
      // an .ort, in one of the two forms piper_voice_model_path knows.
      const std::filesystem::path model_path = piper_voice_model_path(
          onnx_path_.parent_path(),
          piper_voice_stem(onnx_path_.filename().string()));
      if (model_path.empty()) {
        throw std::runtime_error("PiperTTS: no ORT model for voice " +
                                 onnx_path_.stem().string() + " in " +
                                 onnx_path_.parent_path().string());
      }
#ifdef _WIN32
      const std::wstring wmodel = model_path.wstring();
      session_ = Ort::Session(env_, wmodel.c_str(), session_opts);
#else
      const std::string u8 = model_path.string();
      session_ = Ort::Session(env_, u8.c_str(), session_opts);
#endif
    }
    monolith_loaded_ = true;
  }

  explicit Impl(const PiperTTSOptions& opt)
      : speed_(opt.speed),
        ort_provider_names_(opt.ort_provider_names),
        coreml_cache_dir_(opt.coreml_cache_dir),
        normalize_audio_(opt.normalize_audio),
        output_volume_(opt.output_volume),
        noise_scale_override_(opt.piper_noise_scale_override),
        noise_w_override_(opt.piper_noise_w_override),
        tts_asset_files_(opt.tts_asset_files) {
    g2p_opt_ = opt.g2p_options;
    if (g2p_opt_.g2p_root.empty()) {
      g2p_opt_.g2p_root = std::filesystem::current_path();
    }
    explicit_onnx_file_ = !opt.explicit_onnx_path.empty();
    if (!opt.explicit_onnx_json_path.empty()) {
      explicit_onnx_json_path_ = resolve_path_under_root(
          g2p_opt_.g2p_root, opt.explicit_onnx_json_path);
    }
    if (!opt.voices_json_dir.empty()) {
      voices_json_dir_ =
          resolve_path_under_root(g2p_opt_.g2p_root, opt.voices_json_dir);
    }
    user_voices_dir_ = explicit_onnx_file_ || !opt.voices_dir.empty() ||
                       !opt.voices_json_dir.empty();
    resolve_piper_lang(opt.lang, g2p_opt_, g2p_dialect_, data_subdir_,
                       default_onnx_);
    piper_ipa_lang_key_ = piper_ipa_norm_lang_key(opt.lang, data_subdir_);
    if (explicit_onnx_file_) {
      onnx_path_ =
          resolve_path_under_root(g2p_opt_.g2p_root, opt.explicit_onnx_path);
      voices_dir_ = onnx_path_.parent_path();
    } else if (!opt.voices_dir.empty()) {
      voices_dir_ = std::filesystem::path(opt.voices_dir);
    } else {
      voices_dir_ = g2p_opt_.g2p_root / data_subdir_ / "piper-voices";
    }
    onnx_basename_request_ = opt.onnx_model;
    if (explicit_onnx_file_) {
      // onnx_path_ already set
    } else {
      onnx_path_ =
          pick_onnx_path(voices_dir_, onnx_basename_request_, default_onnx_);
    }
    reload_session();
    g2p_ = std::make_unique<MoonshineG2P>(g2p_dialect_, g2p_opt_);
  }

  void set_speed(double s) {
    if (!(s > 0.0) || !std::isfinite(s)) {
      throw std::runtime_error(
          "PiperTTS: speed must be a positive finite number");
    }
    speed_ = s;
  }

  void set_lang(const std::string& lk) {
    resolve_piper_lang(lk, g2p_opt_, g2p_dialect_, data_subdir_, default_onnx_);
    piper_ipa_lang_key_ = piper_ipa_norm_lang_key(lk, data_subdir_);
    if (!explicit_onnx_file_) {
      if (!user_voices_dir_) {
        voices_dir_ = g2p_opt_.g2p_root / data_subdir_ / "piper-voices";
      }
      onnx_path_ =
          pick_onnx_path(voices_dir_, onnx_basename_request_, default_onnx_);
    }
    reload_session();
    g2p_ = std::make_unique<MoonshineG2P>(g2p_dialect_, g2p_opt_);
  }

  void set_onnx_model(std::string_view stem_or_base) {
    onnx_basename_request_ = std::string(trim_ascii_ws_copy(stem_or_base));
    if (!explicit_onnx_file_) {
      onnx_path_ =
          pick_onnx_path(voices_dir_, onnx_basename_request_, default_onnx_);
    }
    reload_session();
  }

  std::vector<float> synthesize(std::string_view text) {
    const std::string ipa = g2p_->text_to_ipa(text, nullptr);
    return synthesize_from_ipa(ipa);
  }

  /// This model's phoneme ids for an IPA string, or empty if none survive.
  std::vector<int64_t> ids_from_ipa(std::string_view ipa_in) const {
    const std::string trimmed_ipa = trim_ascii_ws_copy(ipa_in);
    if (trimmed_ipa.empty()) {
      return {};
    }
    const std::string ipa_for_piper =
        coerce_unknown_ipa_chars_to_piper_inventory(
            normalize_g2p_ipa_for_piper(trimmed_ipa, piper_ipa_lang_key_),
            phoneme_map_keys_, true);
    if (trim_ascii_ws_copy(ipa_for_piper).empty()) {
      return {};
    }
    return ipa_utf8_to_piper_ids(ipa_for_piper, phoneme_id_map_);
  }

  std::vector<float> synthesize_from_ipa(std::string_view ipa_in) {
    const std::vector<int64_t> ids = ids_from_ipa(ipa_in);
    if (ids.size() < 3) {
      return {};
    }
    return run_ort_from_phoneme_ids(ids);
  }

  /// The scales row the model expects, honouring speed and any overrides.
  std::array<float, 3> inference_scales() const {
    double sp = speed_;
    if (sp < 0.25) {
      sp = 0.25;
    }
    if (sp > 4.0) {
      sp = 4.0;
    }
    const float length_scale = length_scale_default_ / static_cast<float>(sp);
    const float ns = noise_scale_override_.has_value()
                         ? noise_scale_override_.value()
                         : noise_scale_;
    const float nw =
        noise_w_override_.has_value() ? noise_w_override_.value() : noise_w_;
    return {ns, length_scale, nw};
  }

  int analyze(std::string_view text) {
    if (!stages_loaded_ || !g2p_) {
      return 0;
    }
    const std::string ipa = g2p_->text_to_ipa(text, nullptr);
    const std::vector<int64_t> ids = ids_from_ipa(ipa);
    if (ids.size() < 3) {
      latent_.clear();
      latent_shape_.clear();
      return 0;
    }
    return run_upstream(ids);
  }

  /// Runs the body over `ids` and keeps what it hands the generator.
  ///
  /// Returns the utterance's length in latent frames. Only one generation runs
  /// at a time, so the latent can live on the engine between this and the
  /// decodes that consume it.
  int run_upstream(const std::vector<int64_t>& ids) {
    latent_.clear();
    latent_shape_.clear();
    const int64_t ntok = static_cast<int64_t>(ids.size());
    const std::array<int64_t, 2> shape_in{1, ntok};
    const std::array<int64_t, 1> shape_one{1};
    const std::array<int64_t, 1> shape_scales{3};
    int64_t input_len = ntok;
    int64_t sid = 0;
    std::array<float, 3> scales = inference_scales();

    std::vector<Ort::Value> inputs;
    std::vector<const char*> names{"input", "input_lengths", "scales"};
    inputs.push_back(Ort::Value::CreateTensor<int64_t>(
        mem_, const_cast<int64_t*>(ids.data()), ids.size(), shape_in.data(),
        shape_in.size()));
    inputs.push_back(Ort::Value::CreateTensor<int64_t>(
        mem_, &input_len, 1, shape_one.data(), shape_one.size()));
    inputs.push_back(Ort::Value::CreateTensor<float>(
        mem_, scales.data(), scales.size(), shape_scales.data(),
        shape_scales.size()));
    if (num_speakers_ > 1) {
      inputs.push_back(Ort::Value::CreateTensor<int64_t>(
          mem_, &sid, 1, shape_one.data(), shape_one.size()));
      names.push_back("sid");
    }
    append_split_weight_inputs(upstream_weights_, mem_, inputs, names);

    std::vector<const char*> out_names;
    out_names.push_back(latent_name_.c_str());
    for (const SeamTensor& tensor : conditioning_) {
      out_names.push_back(tensor.name.c_str());
    }

    Ort::RunOptions run_opts{nullptr};
    auto outputs = upstream_session_.Run(run_opts, names.data(), inputs.data(),
                                         inputs.size(), out_names.data(),
                                         out_names.size());
    const auto info = outputs[0].GetTensorTypeAndShapeInfo();
    if (info.GetElementType() != ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT ||
        info.GetShape().size() != 3) {
      return 0;
    }
    latent_shape_ = info.GetShape();
    const float* values = outputs[0].GetTensorData<float>();
    latent_.assign(values, values + info.GetElementCount());
    for (size_t i = 0; i < conditioning_.size(); ++i) {
      const auto held = outputs[i + 1].GetTensorTypeAndShapeInfo();
      conditioning_[i].shape = held.GetShape();
      const float* data = outputs[i + 1].GetTensorData<float>();
      conditioning_[i].data.assign(data, data + held.GetElementCount());
    }

    const int frames = static_cast<int>(latent_shape_[2]);
    total_native_ = static_cast<size_t>(frames) * static_cast<size_t>(hop_);
    total_out_ = resampled_count(total_native_);
    resample_step_ = total_out_ > 1 ? static_cast<double>(total_native_ - 1) /
                                          static_cast<double>(total_out_ - 1)
                                    : 0.0;
    return frames;
  }

  /// Output samples `resample_linear` would produce from `count` native ones.
  size_t resampled_count(size_t count) const {
    if (native_sample_rate_ == PiperTTS::kSampleRateHz || count < 2) {
      return count;
    }
    const double duration = static_cast<double>(count - 1) /
                            static_cast<double>(native_sample_rate_);
    return std::max<size_t>(
        2, static_cast<size_t>(std::llround(
               duration * static_cast<double>(PiperTTS::kSampleRateHz))) +
               1);
  }

  /// Output samples ``[first_out, last_out)`` of the utterance being decoded.
  ///
  /// The grid is the whole utterance's, not the chunk's: `resample_step_` is
  /// what the one-shot path would use for a render of this length, and every
  /// chunk reads off the same one. Doing it per chunk instead would restart the
  /// interpolation at each join, which both steps the waveform there and lets
  /// the chunks drift out of step with the render they are supposed to
  /// reproduce. `native` starts at sample `offset` of the utterance and, having
  /// been decoded with padding, reaches past both ends of what is asked for.
  std::vector<float> resample_span(const std::vector<float>& native,
                                   size_t offset, size_t first_out,
                                   size_t last_out) const {
    if (last_out <= first_out) {
      return {};
    }
    if (native_sample_rate_ == PiperTTS::kSampleRateHz) {
      const size_t begin = std::min(first_out - offset, native.size());
      const size_t end = std::min(last_out - offset, native.size());
      return std::vector<float>(native.begin() + static_cast<long>(begin),
                                native.begin() + static_cast<long>(end));
    }
    std::vector<float> out;
    out.reserve(last_out - first_out);
    const auto available = static_cast<int64_t>(native.size());
    const auto last_native = static_cast<int64_t>(total_native_) - 1;
    for (size_t j = first_out; j < last_out; ++j) {
      const double position = static_cast<double>(j) * resample_step_;
      const auto whole = static_cast<int64_t>(std::floor(position));
      const double frac = position - static_cast<double>(whole);
      const int64_t left = whole - static_cast<int64_t>(offset);
      // The last output sample lands exactly on the last input one, which has
      // no successor to interpolate towards.
      const int64_t right =
          std::min(whole + 1, last_native) - static_cast<int64_t>(offset);
      const float a = (left >= 0 && left < available)
                          ? native[static_cast<size_t>(left)]
                          : 0.F;
      const float b = (right >= 0 && right < available)
                          ? native[static_cast<size_t>(right)]
                          : a;
      out.push_back(static_cast<float>(static_cast<double>(a) * (1.0 - frac) +
                                       static_cast<double>(b) * frac));
    }
    return out;
  }

  /// The first output sample at or after native position `native_position`.
  size_t first_output_at(size_t native_position) const {
    if (native_sample_rate_ == PiperTTS::kSampleRateHz) {
      return native_position;
    }
    if (resample_step_ <= 0.0) {
      return 0;
    }
    return static_cast<size_t>(
        std::ceil(static_cast<double>(native_position) / resample_step_));
  }

  /// Native-rate audio for latent frames ``[low, high)``, with nothing
  /// trimmed. Padding is the caller's business.
  std::vector<float> run_generator(int low, int high) {
    const int frames = static_cast<int>(latent_shape_[2]);
    const int64_t channels = latent_shape_[1];
    const int span = high - low;

    std::vector<float> slice(static_cast<size_t>(channels) *
                             static_cast<size_t>(span));
    for (int64_t channel = 0; channel < channels; ++channel) {
      const float* source =
          latent_.data() +
          static_cast<size_t>(channel) * static_cast<size_t>(frames) +
          static_cast<size_t>(low);
      std::copy(source, source + span,
                slice.data() +
                    static_cast<size_t>(channel) * static_cast<size_t>(span));
    }
    const std::array<int64_t, 3> slice_shape{1, channels, span};

    std::vector<Ort::Value> inputs;
    std::vector<const char*> names;
    inputs.push_back(Ort::Value::CreateTensor<float>(
        mem_, slice.data(), slice.size(), slice_shape.data(),
        slice_shape.size()));
    names.push_back(latent_name_.c_str());
    for (SeamTensor& tensor : conditioning_) {
      inputs.push_back(Ort::Value::CreateTensor<float>(
          mem_, tensor.data.data(), tensor.data.size(), tensor.shape.data(),
          tensor.shape.size()));
      names.push_back(tensor.name.c_str());
    }
    append_split_weight_inputs(generator_weights_, mem_, inputs, names);

    Ort::RunOptions run_opts{nullptr};
    const char* out_names[] = {"output"};
    auto outputs = generator_session_.Run(run_opts, names.data(), inputs.data(),
                                          inputs.size(), out_names, 1);
    const auto info = outputs[0].GetTensorTypeAndShapeInfo();
    if (info.GetElementType() != ONNX_TENSOR_ELEMENT_DATA_TYPE_FLOAT) {
      throw std::runtime_error("PiperTTS: ONNX output is not float32");
    }
    const float* data = outputs[0].GetTensorData<float>();
    return std::vector<float>(data, data + info.GetElementCount());
  }

  std::vector<float> decode_analyzed(int first, int last) {
    if (!stages_loaded_ || latent_shape_.size() != 3 || hop_ <= 0) {
      return {};
    }
    const int frames = static_cast<int>(latent_shape_[2]);
    first = std::clamp(first, 0, frames);
    last = std::clamp(last, first, frames);
    if (last <= first) {
      return {};
    }
    const int low = std::max(0, first - kSlicePadFrames);
    const int high = std::min(frames, last + kSlicePadFrames);
    const std::vector<float> native = run_generator(low, high);

    const size_t offset = static_cast<size_t>(low) * static_cast<size_t>(hop_);
    const size_t first_out =
        first_output_at(static_cast<size_t>(first) * static_cast<size_t>(hop_));
    // The final chunk runs to the end of the grid, so no sample is left behind
    // by the rounding that places the boundaries.
    const size_t last_out = last == frames
                                ? total_out_
                                : first_output_at(static_cast<size_t>(last) *
                                                  static_cast<size_t>(hop_));
    std::vector<float> wave =
        resample_span(native, offset, first_out, last_out);
    // Peak normalization needs the whole utterance, which streaming does not
    // have, so the level comes from what this voice measured offline instead.
    const float gain = normalize_audio_ ? piper_streaming_gain(piper_voice_stem(
                                              onnx_path_.filename().string())) *
                                              output_volume_
                                        : output_volume_;
    apply_synthesis_output_effects(wave, /*normalize_audio=*/false, gain);
    return wave;
  }

  std::vector<float> synthesize_phoneme_ids(
      const std::vector<int64_t>& phoneme_ids) {
    return run_ort_from_phoneme_ids(phoneme_ids);
  }
};

PiperTTS::PiperTTS(const PiperTTSOptions& opt)
    : impl_(std::make_unique<Impl>(opt)) {}

PiperTTS::~PiperTTS() = default;

PiperTTS::PiperTTS(PiperTTS&&) noexcept = default;
PiperTTS& PiperTTS::operator=(PiperTTS&&) noexcept = default;

void PiperTTS::set_lang(std::string_view lang_cli) {
  impl_->set_lang(std::string(lang_cli));
}

void PiperTTS::set_speed(double speed) { impl_->set_speed(speed); }

double PiperTTS::speed() const { return impl_->speed_; }

void PiperTTS::set_onnx_model(std::string_view basename_or_stem) {
  impl_->set_onnx_model(basename_or_stem);
}

bool PiperTTS::normalize_audio() const { return impl_->normalize_audio_; }

void PiperTTS::set_normalize_audio(bool on) { impl_->normalize_audio_ = on; }

float PiperTTS::output_volume() const { return impl_->output_volume_; }

void PiperTTS::set_output_volume(float volume) {
  impl_->output_volume_ = volume;
}

std::vector<float> PiperTTS::synthesize(std::string_view text) {
  return impl_->synthesize(text);
}

std::vector<float> PiperTTS::synthesize_from_ipa(std::string_view ipa) {
  return impl_->synthesize_from_ipa(ipa);
}

bool PiperTTS::supports_slicing() const { return impl_->stages_loaded_; }

int PiperTTS::frames_per_second() const {
  if (impl_->hop_ <= 0) {
    return 0;
  }
  return impl_->native_sample_rate_ / impl_->hop_;
}

int PiperTTS::analyze(std::string_view text) { return impl_->analyze(text); }

std::vector<float> PiperTTS::decode_analyzed(int first, int last) {
  return impl_->decode_analyzed(first, last);
}

std::vector<float> PiperTTS::synthesize_phoneme_ids(
    const std::vector<int64_t>& phoneme_ids) {
  return impl_->synthesize_phoneme_ids(phoneme_ids);
}

std::vector<std::pair<std::string, bool>> piper_list_voices_with_availability(
    const PiperTTSOptions& opt) {
  static const std::string k_piper_onnx("piper/onnx");
  MoonshineG2POptions g2p_opt = opt.g2p_options;
  if (g2p_opt.g2p_root.empty()) {
    g2p_opt.g2p_root = std::filesystem::current_path();
  }
  const bool explicit_onnx_file = !opt.explicit_onnx_path.empty();
  if (explicit_onnx_file) {
    const std::filesystem::path onnx_path =
        resolve_path_under_root(g2p_opt.g2p_root, opt.explicit_onnx_path);
    const std::string stem = piper_voice_stem(onnx_path.filename().string());
    if (std::filesystem::is_regular_file(onnx_path) ||
        piper_voice_model_present(onnx_path.parent_path(), stem)) {
      return {{stem, true}};
    }
    const auto oit = opt.tts_asset_files.entries.find(k_piper_onnx);
    if (oit != opt.tts_asset_files.entries.end() &&
        oit->second.memory != nullptr && oit->second.memory_size > 0) {
      return {{stem, true}};
    }
    return {{stem, false}};
  }
  // No Piper ONNX layout for Japanese (Kokoro-only); avoid resolve_piper_lang
  // throwing when callers merge Piper + Kokoro voice lists (e.g.
  // ``moonshine_get_tts_voices`` for ``ja`` / ``ja-jp``).
  {
    const std::string lk = normalize_lang_key(opt.lang);
    if (lk == "ja" || lk == "jp" || lk == "ja_jp") {
      return {};
    }
  }
  std::filesystem::path voices_dir;
  std::string default_onnx;
  std::string g2p_dialect;
  std::string data_subdir;
  resolve_piper_lang(opt.lang, g2p_opt, g2p_dialect, data_subdir, default_onnx);
  (void)g2p_dialect;
  if (!opt.voices_dir.empty()) {
    voices_dir = opt.voices_dir;
  } else {
    voices_dir = g2p_opt.g2p_root / data_subdir / "piper-voices";
  }
  std::map<std::string, bool> by_id;
  const auto present = [&](const std::string& stem) {
    return piper_voice_model_present(voices_dir, stem);
  };
  const std::vector<std::string>& bundled =
      piper_bundled_voice_stems_for_data_subdir(data_subdir);
  if (!bundled.empty()) {
    for (const std::string& stem : bundled) {
      by_id[stem] = present(stem);
    }
  } else {
    const std::string def_stem = piper_voice_stem(default_onnx);
    by_id[def_stem] = present(def_stem);
  }
  for (const std::string& stem : piper_voice_stems_on_disk(voices_dir)) {
    by_id[stem] = true;
  }
  std::vector<std::pair<std::string, bool>> out;
  out.reserve(by_id.size());
  for (const auto& pr : by_id) {
    out.emplace_back(pr.first, pr.second);
  }
  return out;
}

bool piper_default_model_bundle_relative_paths(
    std::string_view lang_cli, const MoonshineG2POptions& opt,
    std::vector<std::string>* model_relpaths_out,
    std::string* onnx_json_relpath_out, std::string_view onnx_model_stem) {
  if (model_relpaths_out == nullptr || onnx_json_relpath_out == nullptr) {
    return false;
  }
  try {
    std::string g2p_dialect;
    std::string data_subdir;
    std::string default_onnx;
    resolve_piper_lang(std::string(lang_cli), opt, g2p_dialect, data_subdir,
                       default_onnx);
    const std::string stem_req =
        trim_ascii_ws_copy(std::string(onnx_model_stem));
    const std::string stem = piper_voice_stem(
        stem_req.empty() ? std::string(default_onnx) : stem_req);
    const std::string dir = data_subdir + "/piper-voices/";
    model_relpaths_out->clear();
    for (const std::string& name : piper_voice_model_filenames(stem)) {
      model_relpaths_out->push_back(dir + name);
    }
    // The config keeps its ``.onnx.json`` name whatever form the model ships
    // in.
    *onnx_json_relpath_out = dir + stem + ".onnx.json";
    return true;
  } catch (const std::exception&) {
    return false;
  }
}

}  // namespace moonshine_tts
