#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "japanese-onnx-g2p.h"

#include <doctest/doctest.h>

#include "rule-g2p-test-support.h"

namespace r = moonshine_tts::rule_g2p_test;

TEST_CASE(
    "japanese onnx g2p: first 100 wiki IPA lines match reference when assets "
    "and golden exist") {
  constexpr std::size_t kWikiLines = 100;
  const auto repo = r::repo_root_from_tests_cpp(__FILE__);
  const auto data = r::moonshine_tts_bundled_data_dir_relative();
  const auto model = moonshine_tts::default_japanese_tok_pos_model_dir(data);
  const auto dict = moonshine_tts::default_japanese_dict_path(data);
  const auto wiki =
      r::moonshine_tts_bundled_data_dir_relative() / "ja" / "wiki-text.txt";
  const std::filesystem::path golden =
      r::tests_data_dir(repo) / "ja" / "onnx_g2p_wiki_100.txt";
  if (!r::model_present(model) || !std::filesystem::is_regular_file(dict) ||
      !std::filesystem::is_regular_file(wiki) ||
      !std::filesystem::is_regular_file(golden)) {
    return;
  }
  moonshine_tts::JapaneseOnnxG2p g2p(model, dict, false);
  const auto src = r::read_text_first_lines(wiki, kWikiLines);
  const std::vector<std::string> py = r::ref_lines_prefix(golden, src.size());
  REQUIRE(py.size() == src.size());
  for (std::size_t i = 0; i < src.size(); ++i) {
    INFO("wiki line " << (i + 1));
    CHECK(g2p.text_to_ipa(src[i]) == py[i]);
  }
}
