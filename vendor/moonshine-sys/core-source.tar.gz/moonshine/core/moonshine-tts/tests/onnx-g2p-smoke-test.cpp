#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include <doctest/doctest.h>

#include <cstdlib>
#include <filesystem>

#include "moonshine-g2p.h"
#include "rule-g2p-test-support.h"

using namespace moonshine_tts;
namespace r = moonshine_tts::rule_g2p_test;

TEST_CASE(
    "MoonshineG2P en_us rule-based when MOONSHINE_TTS_MODELS_ROOT is set") {
  const char* root = std::getenv("MOONSHINE_TTS_MODELS_ROOT");
  if (root == nullptr || root[0] == '\0') {
    MESSAGE("skip: export MOONSHINE_TTS_MODELS_ROOT to models/en_us parent");
    return;
  }
  MoonshineG2POptions opt;
  opt.g2p_root = std::filesystem::path(root).parent_path();
  const std::string dialect_dir =
      std::filesystem::path(root).filename().string();
  MoonshineG2P g2p(dialect_dir, opt);
  CHECK_FALSE(g2p.uses_onnx());
  CHECK(g2p.uses_english_rules());
  CHECK_FALSE(g2p.uses_spanish_rules());
  CHECK_FALSE(g2p.uses_german_rules());
  const std::string out = g2p.text_to_ipa("Hello world!");
  CHECK(out.size() > 0);
}

TEST_CASE("MoonshineG2P ja-JP when data/ja assets exist under repo") {
  const auto ja_model_dir = r::moonshine_tts_bundled_data_dir_relative() /
                            "ja" / "roberta_japanese_char_luw_upos_onnx";
  const auto ja_dict =
      r::moonshine_tts_bundled_data_dir_relative() / "ja" / "dict.tsv";
  if (!r::model_present(ja_model_dir) ||
      !std::filesystem::is_regular_file(ja_dict)) {
    return;
  }
  MoonshineG2POptions opt;
  opt.g2p_root = r::moonshine_tts_bundled_data_dir_relative();
  MoonshineG2P g2p("ja", opt);
  CHECK(g2p.uses_japanese_rules());
  CHECK_FALSE(g2p.uses_korean_rules());
  const std::string out = g2p.text_to_ipa("東京に行きます。");
  CHECK(out.find("toɯkjoɯ") != std::string::npos);
}
