// Real frontend/encoder regression: no lost tail, padding-only memory, or
// held-back lookahead after an empty final call. No microphone or downloads.
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <string>
#include <vector>

#include "moonshine-c-api.h"
#include "moonshine-streaming-model.h"

#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include <doctest.h>

namespace {
std::string model_directory() {
  const char *path = std::getenv("MOONSHINE_FINALIZATION_MODEL");
  return path == nullptr ? "tiny-streaming-en" : path;
}

std::vector<float> signal(size_t size) {
  std::vector<float> audio(size);
  for (size_t i = 0; i < size; ++i) {
    audio.at(i) = 0.2f * std::sin(static_cast<float>(i) * 0.13f);
  }
  return audio;
}

void verify_packetization(MoonshineStreamingModel &model,
                          const std::vector<float> &audio, size_t packet,
                          const std::vector<float> &expected_features) {
  CAPTURE(packet);
  const int feature_count = static_cast<int>((audio.size() + 319) / 320);
  MoonshineStreamingState state;
  state.reset(model.config);
  size_t processed = 0;
  for (size_t available = std::min(packet, audio.size());;
       available = std::min(available + packet, audio.size())) {
    size_t consumed = 0;
    REQUIRE(model.encode_audio(&state, audio.data() + processed,
                               available - processed, false, &consumed) == 0);
    CHECK(consumed % 1280 == 0);
    processed += consumed;
    CHECK(processed <= available);
    if (available == audio.size()) break;
  }

  size_t consumed = 0;
  REQUIRE(model.encode_audio(&state, audio.data() + processed,
                             audio.size() - processed, true, &consumed) == 0);
  processed += consumed;
  CHECK(processed == audio.size());
  CHECK(state.accumulated_feature_count == feature_count);
  CHECK(state.encoder_frames_emitted == feature_count);
  CHECK(state.memory_len == feature_count);
  CHECK(state.frame_count == static_cast<int64_t>((audio.size() + 79) / 80));
  CHECK(state.accumulated_features == expected_features);
  CHECK(std::all_of(state.memory.begin(), state.memory.end(),
                    [](float value) { return std::isfinite(value); }));

  const auto memory = state.memory;
  const auto features = state.accumulated_features;
  REQUIRE(model.encode_audio(&state, nullptr, 0, true, &consumed) == 0);
  CHECK(consumed == 0);
  CHECK(state.memory == memory);
  CHECK(state.accumulated_features == features);
}
struct ScopedTranscriber {
  int32_t handle;
  ~ScopedTranscriber() { moonshine_free_transcriber(handle); }
};
}  // namespace

TEST_CASE("streaming finalization preserves real audio and encoder lookahead") {
  MoonshineStreamingModel model;
  const std::string directory = model_directory();
  REQUIRE(model.load(directory.c_str(), (directory + "/tokenizer.bin").c_str(),
                     MOONSHINE_MODEL_ARCH_TINY_STREAMING) == 0);
  REQUIRE(model.config.frame_len == 80);

  for (const size_t tail :
       {0u, 1u, 79u, 80u, 81u, 319u, 320u, 321u, 768u, 1279u}) {
    CAPTURE(tail);
    const auto audio = signal(1280 * 8 + tail);
    const int valid_features = static_cast<int>((audio.size() + 319) / 320);

    // Oracle uses only aligned frontend inputs, including the old English
    // graph ABI. Trim padding before encoder attention, not after decoding.
    MoonshineStreamingState oracle;
    oracle.reset(model.config);
    auto aligned = audio;
    aligned.resize((audio.size() + 1279) / 1280 * 1280, 0.0f);
    for (size_t offset = 0; offset < aligned.size(); offset += 1280) {
      REQUIRE(model.process_audio_chunk(&oracle, aligned.data() + offset, 1280,
                                        nullptr) == 0);
    }
    oracle.accumulated_features.resize(valid_features *
                                       model.config.encoder_dim);

    for (const size_t packet : {17u, 79u, 80u, 997u, 1280u, 2560u}) {
      verify_packetization(model, audio, packet, oracle.accumulated_features);
    }
  }

  SUBCASE("aligned input still flushes lookahead without additional samples") {
    auto audio = signal(1280 * 8);
    MoonshineStreamingState state;
    state.reset(model.config);
    size_t consumed = 0;
    REQUIRE(model.encode_audio(&state, audio.data(), audio.size(), false,
                               &consumed) == 0);
    REQUIRE(consumed == audio.size());
    CHECK(state.memory_len < state.accumulated_feature_count);
    REQUIRE(model.encode_audio(&state, nullptr, 0, true, &consumed) == 0);
    CHECK(consumed == 0);
    CHECK(state.memory_len == state.accumulated_feature_count);
  }

  SUBCASE("empty input stays empty and null nonempty input fails") {
    MoonshineStreamingState state;
    state.reset(model.config);
    size_t consumed = 99;
    REQUIRE(model.encode_audio(&state, nullptr, 0, true, &consumed) == 0);
    CHECK(consumed == 0);
    CHECK(state.memory.empty());
    CHECK(model.encode_audio(&state, nullptr, 1, true, &consumed) != 0);
    CHECK(consumed == 0);
  }
}

TEST_CASE("finalizing silence does not create transcript text") {
  const std::string directory = model_directory();
  ScopedTranscriber transcriber{moonshine_load_transcriber_from_files(
      directory.c_str(), MOONSHINE_MODEL_ARCH_TINY_STREAMING, nullptr, 0,
      MOONSHINE_HEADER_VERSION)};
  REQUIRE(transcriber.handle >= 0);
  for (const size_t length : {1u, 79u, 1280u, 32001u}) {
    CAPTURE(length);
    std::vector<float> silence(length, 0.0f);
    transcript_t *transcript = nullptr;
    REQUIRE(moonshine_transcribe_without_streaming(
                transcriber.handle, silence.data(), silence.size(), 16000, 0,
                &transcript) == 0);
    REQUIRE(transcript != nullptr);
    for (uint64_t i = 0; i < transcript->line_count; ++i) {
      CHECK(std::string(transcript->lines[i].text).empty());
    }
  }
}
