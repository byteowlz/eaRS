#include "moonshine-c-api.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdlib>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "debug-utils.h"
#include "string-utils.h"

#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include <doctest.h>

namespace {

std::filesystem::path find_de_piper_voices_dir() {
  const std::filesystem::path candidates[] = {
      std::filesystem::path("core") / "moonshine-tts" / "data" / "de" /
          "piper-voices",
      std::filesystem::path("..") / "core" / "moonshine-tts" / "data" / "de" /
          "piper-voices",
  };
  for (const auto& c : candidates) {
    if (std::filesystem::is_directory(c)) {
      return c;
    }
  }
  return {};
}

std::vector<uint8_t> read_binary_file(const std::filesystem::path& p) {
  std::ifstream f(p, std::ios::binary);
  if (!f) {
    return {};
  }
  return std::vector<uint8_t>((std::istreambuf_iterator<char>(f)),
                              std::istreambuf_iterator<char>());
}

/// Resolve ``moonshine-tts/data`` for tests run from ``test-assets/``, repo
/// root, or ``core/build``.
std::optional<std::filesystem::path> find_moonshine_tts_data_dir() {
  namespace fs = std::filesystem;
  const fs::path cwd = fs::current_path();
  const fs::path candidates[] = {
      cwd / "core" / "moonshine-tts" / "data",
      cwd.parent_path() / "core" / "moonshine-tts" / "data",
      cwd / "moonshine-tts" / "data",
      cwd.parent_path() / "moonshine-tts" / "data",
      cwd / ".." / "moonshine-tts" / "data",
      cwd / ".." / ".." / "moonshine-tts" / "data",
  };
  for (const auto& p : candidates) {
    std::error_code ec;
    const fs::path abs = fs::absolute(p, ec);
    if (ec) {
      continue;
    }
    if (fs::is_directory(abs / "en_us")) {
      return abs;
    }
  }
  return std::nullopt;
}

void free_phonemes_output(const char* ipa) {
  std::free(const_cast<char*>(ipa));
}

/// Creates a phonemizer with ``g2p_root`` = *data_root*, runs ``text`` → IPA,
/// frees output.
void grapheme_phonemizer_smoke(const std::filesystem::path& data_root,
                               const char* language, const char* text) {
  const std::string g2p_root_str = data_root.string();
  const moonshine_option_t opts[] = {
      {"g2p_root", g2p_root_str.c_str()},
      {"log_profiling", "true"},
  };
  const uint64_t n_opt = sizeof(opts) / sizeof(opts[0]);
  int32_t h = moonshine_create_grapheme_to_phonemizer_from_files(
      language, nullptr, 0, opts, n_opt, MOONSHINE_HEADER_VERSION);
  REQUIRE(h >= 0);
  const char* ipa = nullptr;
  uint64_t phoneme_count = 0;
  REQUIRE(moonshine_text_to_phonemes(h, text, nullptr, 0, &ipa,
                                     &phoneme_count) == MOONSHINE_ERROR_NONE);
  REQUIRE(phoneme_count > 1);
  REQUIRE(ipa != nullptr);
  REQUIRE(std::strlen(ipa) > 0);
  free_phonemes_output(ipa);
  moonshine_free_grapheme_to_phonemizer(h);
}

struct GraphemePhonemizerLangCase {
  const char* language;
  const char* text;
  /// If non-null, skip the case when this path is not a regular file under the
  /// data root.
  const char* required_relative_file;
};

}  // namespace

TEST_CASE("moonshine-test-v2") {
  SUBCASE("transcribe-complete") {
    std::string wav_path = "two_cities.wav";
    REQUIRE(std::filesystem::exists(wav_path));
    float* wav_data = nullptr;
    size_t wav_data_size = 0;
    int32_t wav_sample_rate = 0;
    REQUIRE(load_wav_data(wav_path.c_str(), &wav_data, &wav_data_size,
                          &wav_sample_rate));
    REQUIRE(wav_data != nullptr);
    REQUIRE(wav_data_size > 0);

    int32_t model_arch = MOONSHINE_MODEL_ARCH_TINY;

    std::string root_model_path = "tiny-en";
    REQUIRE(std::filesystem::exists(root_model_path));
    int32_t transcriber_handle = moonshine_load_transcriber_from_files(
        root_model_path.c_str(), model_arch, nullptr, 0,
        MOONSHINE_HEADER_VERSION);
    REQUIRE(transcriber_handle >= 0);

    struct transcript_t* transcript = nullptr;
    int32_t transcribe_error = moonshine_transcribe_without_streaming(
        transcriber_handle, wav_data, wav_data_size, wav_sample_rate, 0,
        &transcript);
    REQUIRE(transcribe_error == MOONSHINE_ERROR_NONE);
    REQUIRE(transcript != nullptr);
    REQUIRE(transcript->line_count > 0);
    for (size_t i = 0; i < transcript->line_count; i++) {
      const struct transcript_line_t& line = transcript->lines[i];
      REQUIRE(line.text != nullptr);
      REQUIRE(line.audio_data != nullptr);
      REQUIRE(line.audio_data_count > 0);
      REQUIRE(line.start_time >= 0.0f);
      REQUIRE(line.duration > 0.0f);
      REQUIRE(line.is_complete == 1);
      REQUIRE(line.is_updated == 1);
      REQUIRE(line.is_new == 1);
      REQUIRE(line.has_text_changed == 1);
      // Speaker identification is opt-in, so no spans by default.
      REQUIRE(line.speaker_spans == nullptr);
      REQUIRE(line.speaker_span_count == 0);
    }
  }
  SUBCASE("transcribe-stream") {
    std::string wav_path = "two_cities.wav";
    REQUIRE(std::filesystem::exists(wav_path));
    float* wav_data = nullptr;
    size_t wav_data_size = 0;
    int32_t wav_sample_rate = 0;
    REQUIRE(load_wav_data(wav_path.c_str(), &wav_data, &wav_data_size,
                          &wav_sample_rate));
    REQUIRE(wav_data != nullptr);
    REQUIRE(wav_data_size > 0);

    int32_t model_arch = MOONSHINE_MODEL_ARCH_TINY;

    std::string root_model_path = "tiny-en";
    REQUIRE(std::filesystem::exists(root_model_path));
    const moonshine_option_t options[] = {
        {"identify_speakers", "false"},
    };
    const uint64_t options_count = sizeof(options) / sizeof(options[0]);

    int32_t transcriber_handle = moonshine_load_transcriber_from_files(
        root_model_path.c_str(), model_arch, options, options_count,
        MOONSHINE_HEADER_VERSION);
    REQUIRE(transcriber_handle >= 0);

    int32_t stream_id = moonshine_create_stream(transcriber_handle, 0);
    REQUIRE(stream_id >= 0);
    int32_t start_error = moonshine_start_stream(transcriber_handle, stream_id);
    REQUIRE(start_error == MOONSHINE_ERROR_NONE);

    struct transcript_t* transcript = nullptr;
    const float chunk_duration_seconds = 0.0723f;
    const size_t chunk_size =
        (size_t)(chunk_duration_seconds * wav_sample_rate);
    size_t samples_since_last_transcription = 0;
    const size_t samples_between_transcriptions =
        (size_t)(wav_sample_rate * 0.481f);
    for (size_t i = 0; i < wav_data_size; i += chunk_size) {
      const float* chunk_data = wav_data + i;
      const size_t chunk_data_size = std::min(chunk_size, wav_data_size - i);
      moonshine_transcribe_add_audio_to_stream(transcriber_handle, stream_id,
                                               chunk_data, chunk_data_size,
                                               wav_sample_rate, 0);
      samples_since_last_transcription += chunk_data_size;
      if (samples_since_last_transcription < samples_between_transcriptions) {
        continue;
      }
      samples_since_last_transcription = 0;
      int32_t transcribe_error = moonshine_transcribe_stream(
          transcriber_handle, stream_id, 0, &transcript);
      REQUIRE(transcribe_error == MOONSHINE_ERROR_NONE);
      REQUIRE(transcript != nullptr);
      bool any_updated_lines = false;
      for (size_t j = 0; j < transcript->line_count; j++) {
        const struct transcript_line_t& line = transcript->lines[j];
        REQUIRE(line.text != nullptr);
        REQUIRE(line.audio_data != nullptr);
        REQUIRE(line.audio_data_count > 0);
        REQUIRE(line.start_time >= 0.0f);
        REQUIRE(line.duration > 0.0f);
        REQUIRE(line.speaker_spans == nullptr);
        REQUIRE(line.speaker_span_count == 0);
        // There should be at most one incomplete line at the end of the
        // transcript.
        if (line.is_complete == 0) {
          const bool is_last_line = (j == (transcript->line_count - 1));
          if (!is_last_line) {
            LOGF(
                "Incomplete line %zu ('%s', %.2fs) is not the last line "
                "%" PRId64,
                j, line.text, line.start_time, transcript->line_count - 1);
          }
          REQUIRE(is_last_line);
        }
        if (line.is_updated) {
          any_updated_lines = true;
        } else {
          // If an earlier line has been updated, then all later lines should
          // have been updated as well.
          REQUIRE(!any_updated_lines);
        }
        if (!line.is_updated) {
          continue;
        }
        LOGF("%.1f (#%" PRId64 "): %s", line.start_time, line.id, line.text);
      }
    }
    int32_t stop_error = moonshine_stop_stream(transcriber_handle, stream_id);
    REQUIRE(stop_error == MOONSHINE_ERROR_NONE);
    int32_t final_error = moonshine_transcribe_stream(
        transcriber_handle, stream_id, 0, &transcript);
    REQUIRE(final_error == MOONSHINE_ERROR_NONE);
    REQUIRE(transcript != nullptr);
    REQUIRE(transcript->line_count > 0);
    for (size_t j = 0; j < transcript->line_count; j++) {
      REQUIRE(transcript->lines[j].is_complete == 1);
    }
    LOGF("Transcript: %s", moonshine_transcript_to_string(transcript));
    moonshine_free_stream(transcriber_handle, stream_id);
  }
  SUBCASE("transcribe-stream-after-stop-without-partials") {
    std::string wav_path = "two_cities.wav";
    REQUIRE(std::filesystem::exists(wav_path));
    float* wav_data = nullptr;
    size_t wav_data_size = 0;
    int32_t wav_sample_rate = 0;
    REQUIRE(load_wav_data(wav_path.c_str(), &wav_data, &wav_data_size,
                          &wav_sample_rate));
    REQUIRE(wav_data != nullptr);
    REQUIRE(wav_data_size > 0);
    REQUIRE(wav_data_size >= static_cast<size_t>(wav_sample_rate) * 10);
    wav_data_size = static_cast<size_t>(wav_sample_rate) * 10;

    std::string root_model_path = "tiny-en";
    REQUIRE(std::filesystem::exists(root_model_path));
    int32_t transcriber_handle = moonshine_load_transcriber_from_files(
        root_model_path.c_str(), MOONSHINE_MODEL_ARCH_TINY, nullptr, 0,
        MOONSHINE_HEADER_VERSION);
    REQUIRE(transcriber_handle >= 0);

    int32_t stream_id = moonshine_create_stream(transcriber_handle, 0);
    REQUIRE(stream_id >= 0);
    REQUIRE(moonshine_start_stream(transcriber_handle, stream_id) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(moonshine_transcribe_add_audio_to_stream(
                transcriber_handle, stream_id, wav_data, wav_data_size,
                wav_sample_rate, 0) == MOONSHINE_ERROR_NONE);
    REQUIRE(moonshine_stop_stream(transcriber_handle, stream_id) ==
            MOONSHINE_ERROR_NONE);

    struct transcript_t* transcript = nullptr;
    REQUIRE(moonshine_transcribe_stream(transcriber_handle, stream_id, 0,
                                        &transcript) == MOONSHINE_ERROR_NONE);
    REQUIRE(transcript != nullptr);
    REQUIRE(transcript->line_count > 0);
    bool any_text = false;
    for (size_t j = 0; j < transcript->line_count; j++) {
      const struct transcript_line_t& line = transcript->lines[j];
      REQUIRE(line.is_complete == 1);
      if (line.text != nullptr && line.text[0] != '\0') {
        any_text = true;
      }
    }
    REQUIRE(any_text);
    LOGF("Transcript after stop: %s",
         moonshine_transcript_to_string(transcript));
    moonshine_free_stream(transcriber_handle, stream_id);
    moonshine_free_transcriber(transcriber_handle);
    free(wav_data);
  }
  SUBCASE("transcribe-complete-from-memory") {
    std::string wav_path = "two_cities.wav";
    REQUIRE(std::filesystem::exists(wav_path));
    float* wav_data = nullptr;
    size_t wav_data_size = 0;
    int32_t wav_sample_rate = 0;
    REQUIRE(load_wav_data(wav_path.c_str(), &wav_data, &wav_data_size,
                          &wav_sample_rate));
    REQUIRE(wav_data != nullptr);
    REQUIRE(wav_data_size > 0);

    int32_t model_arch = MOONSHINE_MODEL_ARCH_TINY;

    std::string root_model_path = "tiny-en";
    REQUIRE(std::filesystem::exists(root_model_path));
    std::string encoder_model_path =
        append_path_component(root_model_path, "encoder_model.ort");
    std::string decoder_model_path =
        append_path_component(root_model_path, "decoder_model_merged.ort");
    std::string tokenizer_path =
        append_path_component(root_model_path, "tokenizer.bin");
    REQUIRE(std::filesystem::exists(encoder_model_path));
    REQUIRE(std::filesystem::exists(decoder_model_path));
    REQUIRE(std::filesystem::exists(tokenizer_path));
    std::vector<uint8_t> encoder_model_data =
        load_file_into_memory(encoder_model_path);
    std::vector<uint8_t> decoder_model_data =
        load_file_into_memory(decoder_model_path);
    std::vector<uint8_t> tokenizer_data = load_file_into_memory(tokenizer_path);
    REQUIRE(encoder_model_data.size() > 0);
    REQUIRE(decoder_model_data.size() > 0);
    REQUIRE(tokenizer_data.size() > 0);

    const moonshine_option_t options[] = {
        {"return_audio_data", "false"},
    };
    const uint64_t options_count = sizeof(options) / sizeof(options[0]);

    // moonshine_load_transcriber_from_memory is deprecated and refuses
    // clients built against MOONSHINE_FROM_MEMORY_REMOVED_VERSION or newer, so
    // this passes the last version that still supports it to check that
    // existing binaries keep working.
    const int32_t legacy_version = MOONSHINE_FROM_MEMORY_REMOVED_VERSION - 1;
    int32_t transcriber_handle = moonshine_load_transcriber_from_memory(
        encoder_model_data.data(), encoder_model_data.size(),
        decoder_model_data.data(), decoder_model_data.size(),
        tokenizer_data.data(), tokenizer_data.size(),
        /*spelling_model_data=*/nullptr, /*spelling_model_data_size=*/0,
        model_arch, options, options_count, legacy_version);
    REQUIRE(transcriber_handle >= 0);

    // A client built against the current header has to use
    // moonshine_load_transcriber_from_memory_files instead.
    const int32_t refused_handle = moonshine_load_transcriber_from_memory(
        encoder_model_data.data(), encoder_model_data.size(),
        decoder_model_data.data(), decoder_model_data.size(),
        tokenizer_data.data(), tokenizer_data.size(),
        /*spelling_model_data=*/nullptr, /*spelling_model_data_size=*/0,
        model_arch, options, options_count, MOONSHINE_HEADER_VERSION);
    REQUIRE(refused_handle == MOONSHINE_ERROR_INVALID_ARGUMENT);

    struct transcript_t* transcript = nullptr;
    int32_t transcribe_error = moonshine_transcribe_without_streaming(
        transcriber_handle, wav_data, wav_data_size, wav_sample_rate, 0,
        &transcript);
    REQUIRE(transcribe_error == MOONSHINE_ERROR_NONE);
    REQUIRE(transcript != nullptr);
    REQUIRE(transcript->line_count > 0);
    for (size_t i = 0; i < transcript->line_count; i++) {
      const struct transcript_line_t& line = transcript->lines[i];
      REQUIRE(line.text != nullptr);
      REQUIRE(line.audio_data == nullptr);
      REQUIRE(line.audio_data_count == 0);
      REQUIRE(line.start_time >= 0.0f);
      REQUIRE(line.duration > 0.0f);
      REQUIRE(line.is_complete == 1);
      REQUIRE(line.is_updated == 1);
      REQUIRE(line.speaker_spans == nullptr);
      REQUIRE(line.speaker_span_count == 0);
    }
  }
  SUBCASE("transcribe-without-streaming-skip-transcription") {
    std::string wav_path = "two_cities.wav";
    REQUIRE(std::filesystem::exists(wav_path));
    float* wav_data = nullptr;
    size_t wav_data_size = 0;
    int32_t wav_sample_rate = 0;
    REQUIRE(load_wav_data(wav_path.c_str(), &wav_data, &wav_data_size,
                          &wav_sample_rate));
    REQUIRE(wav_data != nullptr);
    REQUIRE(wav_data_size > 0);

    int32_t model_arch = MOONSHINE_MODEL_ARCH_TINY;

    const moonshine_option_t options[] = {
        {"skip_transcription", "true"},
    };
    const uint64_t options_count = sizeof(options) / sizeof(options[0]);
    std::string root_model_path = "tiny-en";
    REQUIRE(std::filesystem::exists(root_model_path));
    int32_t transcriber_handle = moonshine_load_transcriber_from_files(
        root_model_path.c_str(), model_arch, options, options_count,
        MOONSHINE_HEADER_VERSION);
    REQUIRE(transcriber_handle >= 0);

    struct transcript_t* transcript = nullptr;
    int32_t transcribe_error = moonshine_transcribe_without_streaming(
        transcriber_handle, wav_data, wav_data_size, wav_sample_rate, 0,
        &transcript);
    REQUIRE(transcribe_error == MOONSHINE_ERROR_NONE);
    REQUIRE(transcript != nullptr);
    REQUIRE(transcript->line_count > 0);
    for (size_t i = 0; i < transcript->line_count; i++) {
      const struct transcript_line_t& line = transcript->lines[i];
      REQUIRE(line.text == nullptr);
      REQUIRE(line.audio_data != nullptr);
      REQUIRE(line.audio_data_count > 0);
      REQUIRE(line.start_time >= 0.0f);
      REQUIRE(line.duration > 0.0f);
      REQUIRE(line.is_complete == 1);
      REQUIRE(line.is_updated == 1);
      REQUIRE(line.is_new == 1);
      REQUIRE(line.has_text_changed == 0);
    }
  }
  SUBCASE("transcribe-without-streaming-vad-threshold-0") {
    std::string wav_path = "beckett.wav";
    REQUIRE(std::filesystem::exists(wav_path));
    float* wav_data = nullptr;
    size_t wav_data_size = 0;
    int32_t wav_sample_rate = 0;
    REQUIRE(load_wav_data(wav_path.c_str(), &wav_data, &wav_data_size,
                          &wav_sample_rate));
    REQUIRE(wav_data != nullptr);
    REQUIRE(wav_data_size > 0);

    int32_t model_arch = MOONSHINE_MODEL_ARCH_TINY;

    const moonshine_option_t options[] = {
        {"vad_threshold", "0.0"},
    };
    const uint64_t options_count = sizeof(options) / sizeof(options[0]);
    std::string root_model_path = "tiny-en";
    REQUIRE(std::filesystem::exists(root_model_path));
    int32_t transcriber_handle = moonshine_load_transcriber_from_files(
        root_model_path.c_str(), model_arch, options, options_count,
        MOONSHINE_HEADER_VERSION);
    REQUIRE(transcriber_handle >= 0);

    struct transcript_t* transcript = nullptr;
    int32_t transcribe_error = moonshine_transcribe_without_streaming(
        transcriber_handle, wav_data, wav_data_size, wav_sample_rate, 0,
        &transcript);
    REQUIRE(transcribe_error == MOONSHINE_ERROR_NONE);
    REQUIRE(transcript != nullptr);
    REQUIRE(transcript->line_count == 1);
    const struct transcript_line_t& line = transcript->lines[0];
    REQUIRE(line.text != nullptr);
    REQUIRE(line.audio_data != nullptr);
    const int32_t hop_size = 256;
    const size_t expected_audio_data_size =
        (size_t)(wav_data_size * wav_sample_rate / 16000.0f);
    const size_t expected_audio_data_size_min =
        expected_audio_data_size - hop_size;
    const size_t expected_audio_data_size_max =
        expected_audio_data_size + hop_size;
    REQUIRE(line.audio_data_count >= expected_audio_data_size_min);
    REQUIRE(line.audio_data_count <= expected_audio_data_size_max);
    REQUIRE(line.start_time < 0.001f);
    REQUIRE(line.duration > 0.0f);
    REQUIRE(line.is_complete == 1);
    REQUIRE(line.is_updated == 1);
    REQUIRE(line.is_new == 1);
    REQUIRE(line.has_text_changed == 1);
  }
  SUBCASE("transcribe-valid-options") {
    int32_t model_arch = MOONSHINE_MODEL_ARCH_TINY;
    const moonshine_option_t options[] = {
        {"skip_transcription", "true"},
        {"transcription_interval", "0.5"},
        {"vad_threshold", "0.5"},
        {"save_input_wav_path", "test.wav"},
        {"log_api_calls", "true"},
        {"log_ort_run", "true"},
        {"vad_window_duration", "0.5"},
        {"vad_hop_size", "512"},
        {"vad_look_behind_sample_count", "8192"},
        {"vad_max_segment_duration", "15.0"},
        {"max_tokens_per_second", "6.5"},
        {"identify_speakers", "true"},
        {"diarization_model_dir", "diarization"},
        {"diarization_cluster_cadence", "2.0"},
        {"diarization_analyze_cadence", "1.0"},
        {"diarization_cluster_window_sec", "120.0"},
        {"return_audio_data", "false"},
        {"log_output_text", "true"},
        {"ort_providers", "CPU"},
        {"coreml_cache_dir", "/tmp/moonshine-coreml-cache"},
        {"keyterms", "Kubernetes, Anushka Sharma"},
        {"keyterm_boost", "4.0"},
        {"context", "Migration notes for the platform team."},
        {"context_max_terms", "50"},
    };
    const uint64_t options_count = sizeof(options) / sizeof(options[0]);
    std::string root_model_path = "tiny-en";
    REQUIRE(std::filesystem::exists(root_model_path));
    int32_t transcriber_handle = moonshine_load_transcriber_from_files(
        root_model_path.c_str(), model_arch, options, options_count,
        MOONSHINE_HEADER_VERSION);
    REQUIRE(transcriber_handle >= 0);
  }
  SUBCASE("set-keyterms-at-runtime") {
    std::string root_model_path = "tiny-streaming-en";
    REQUIRE(std::filesystem::exists(root_model_path));
    int32_t transcriber_handle = moonshine_load_transcriber_from_files(
        root_model_path.c_str(), MOONSHINE_MODEL_ARCH_TINY_STREAMING, nullptr,
        0, MOONSHINE_HEADER_VERSION);
    REQUIRE(transcriber_handle >= 0);
    // Setting, replacing and clearing all succeed on a streaming model.
    CHECK(moonshine_transcriber_set_keyterms(transcriber_handle,
                                             "Kubernetes, Anushka Sharma") ==
          MOONSHINE_ERROR_NONE);
    CHECK(moonshine_transcriber_set_keyterms(transcriber_handle, "Ceph") ==
          MOONSHINE_ERROR_NONE);
    CHECK(moonshine_transcriber_set_keyterms(transcriber_handle, "") ==
          MOONSHINE_ERROR_NONE);
    CHECK(moonshine_transcriber_set_keyterms(transcriber_handle, nullptr) ==
          MOONSHINE_ERROR_NONE);
    moonshine_free_transcriber(transcriber_handle);

    // An unknown handle is reported rather than crashing.
    CHECK(moonshine_transcriber_set_keyterms(-1, "Kubernetes") !=
          MOONSHINE_ERROR_NONE);

    // The non-streaming architectures have no biasable decode path, so asking
    // for key terms there is an error rather than a silent no-op.
    int32_t non_streaming_handle = moonshine_load_transcriber_from_files(
        "tiny-en", MOONSHINE_MODEL_ARCH_TINY, nullptr, 0,
        MOONSHINE_HEADER_VERSION);
    REQUIRE(non_streaming_handle >= 0);
    CHECK(moonshine_transcriber_set_keyterms(
              non_streaming_handle, "Kubernetes") != MOONSHINE_ERROR_NONE);
    moonshine_free_transcriber(non_streaming_handle);
  }
  SUBCASE("set-context-at-runtime") {
    std::string root_model_path = "tiny-streaming-en";
    REQUIRE(std::filesystem::exists(root_model_path));
    int32_t transcriber_handle = moonshine_load_transcriber_from_files(
        root_model_path.c_str(), MOONSHINE_MODEL_ARCH_TINY_STREAMING, nullptr,
        0, MOONSHINE_HEADER_VERSION);
    REQUIRE(transcriber_handle >= 0);
    const char* context =
        "We will move the remaining services onto Kubernetes this quarter, "
        "with Ceph behind the storage classes and etcd holding cluster state.";
    // A cap of its own, the default asked for with zero, and a passage far
    // shorter than either cap all succeed.
    CHECK(moonshine_transcriber_set_context(transcriber_handle, context, 10) ==
          MOONSHINE_ERROR_NONE);
    CHECK(moonshine_transcriber_set_context(transcriber_handle, context, 0) ==
          MOONSHINE_ERROR_NONE);
    // Clearing, either way of saying it.
    CHECK(moonshine_transcriber_set_context(transcriber_handle, "", 0) ==
          MOONSHINE_ERROR_NONE);
    CHECK(moonshine_transcriber_set_context(transcriber_handle, nullptr, 0) ==
          MOONSHINE_ERROR_NONE);
    moonshine_free_transcriber(transcriber_handle);

    // An unknown handle is reported rather than crashing.
    CHECK(moonshine_transcriber_set_context(-1, context, 0) !=
          MOONSHINE_ERROR_NONE);

    // Same as key terms: no biasable decode path, so this is an error rather
    // than a silent no-op, and an empty passage is refused too so that the
    // caller learns from the call it made.
    int32_t non_streaming_handle = moonshine_load_transcriber_from_files(
        "tiny-en", MOONSHINE_MODEL_ARCH_TINY, nullptr, 0,
        MOONSHINE_HEADER_VERSION);
    REQUIRE(non_streaming_handle >= 0);
    CHECK(moonshine_transcriber_set_context(non_streaming_handle, context, 0) !=
          MOONSHINE_ERROR_NONE);
    CHECK(moonshine_transcriber_set_context(non_streaming_handle, "", 0) !=
          MOONSHINE_ERROR_NONE);
    moonshine_free_transcriber(non_streaming_handle);

    // The load option has to refuse the same architectures the runtime call
    // does, rather than accepting a passage it can never use.
    const moonshine_option_t context_options[] = {{"context", context}};
    CHECK(moonshine_load_transcriber_from_files(
              "tiny-en", MOONSHINE_MODEL_ARCH_TINY, context_options, 1,
              MOONSHINE_HEADER_VERSION) < 0);
  }
  SUBCASE("transcribe-invalid-option") {
    const moonshine_option_t options[] = {
        {"invalid_option", "true"},
    };
    const uint64_t options_count = sizeof(options) / sizeof(options[0]);
    int32_t model_arch = MOONSHINE_MODEL_ARCH_TINY;
    std::string root_model_path = "tiny-en";
    REQUIRE(std::filesystem::exists(root_model_path));
    int32_t transcriber_handle = moonshine_load_transcriber_from_files(
        root_model_path.c_str(), model_arch, options, options_count,
        MOONSHINE_HEADER_VERSION);
    REQUIRE(transcriber_handle < 0);
  }
  SUBCASE("spelling-mode-flag-noop-without-model") {
    // Smoke check: passing MOONSHINE_FLAG_SPELLING_MODE without
    // configuring a spelling model must not crash and must not affect
    // the regular transcription output.
    std::string wav_path = "two_cities.wav";
    REQUIRE(std::filesystem::exists(wav_path));
    float* wav_data = nullptr;
    size_t wav_data_size = 0;
    int32_t wav_sample_rate = 0;
    REQUIRE(load_wav_data(wav_path.c_str(), &wav_data, &wav_data_size,
                          &wav_sample_rate));
    int32_t model_arch = MOONSHINE_MODEL_ARCH_TINY;
    std::string root_model_path = "tiny-en";
    REQUIRE(std::filesystem::exists(root_model_path));
    int32_t transcriber_handle = moonshine_load_transcriber_from_files(
        root_model_path.c_str(), model_arch, nullptr, 0,
        MOONSHINE_HEADER_VERSION);
    REQUIRE(transcriber_handle >= 0);
    struct transcript_t* transcript = nullptr;
    int32_t err = moonshine_transcribe_without_streaming(
        transcriber_handle, wav_data, wav_data_size, wav_sample_rate,
        MOONSHINE_FLAG_SPELLING_MODE, &transcript);
    REQUIRE(err == MOONSHINE_ERROR_NONE);
    REQUIRE(transcript != nullptr);
    moonshine_free_transcriber(transcriber_handle);
    free(wav_data);
  }
  SUBCASE("spelling-mode-replaces-line-text") {
    // End-to-end check: hand the transcriber a spelling .ort and a
    // single "alpha" recording. With MOONSHINE_FLAG_SPELLING_MODE
    // set, ``line.text`` for the completed segment must be the
    // single resolved character, not the raw ASR transcription.
    std::string spelling_path = "spelling_cnn.ort";
    if (!std::filesystem::exists(spelling_path)) {
      MESSAGE("skip: spelling_cnn.ort not in test-assets");
      return;
    }
    std::string wav_path = "alphanumeric/a/petewarden_nohash_0.wav";
    if (!std::filesystem::exists(wav_path)) {
      MESSAGE("skip: alphanumeric clip not in test-assets");
      return;
    }
    float* wav_data = nullptr;
    size_t wav_data_size = 0;
    int32_t wav_sample_rate = 0;
    REQUIRE(load_wav_data(wav_path.c_str(), &wav_data, &wav_data_size,
                          &wav_sample_rate));
    int32_t model_arch = MOONSHINE_MODEL_ARCH_TINY;
    std::string root_model_path = "tiny-en";
    REQUIRE(std::filesystem::exists(root_model_path));
    const moonshine_option_t options[] = {
        {"spelling_model_path", spelling_path.c_str()},
    };
    const uint64_t options_count = sizeof(options) / sizeof(options[0]);
    int32_t transcriber_handle = moonshine_load_transcriber_from_files(
        root_model_path.c_str(), model_arch, options, options_count,
        MOONSHINE_HEADER_VERSION);
    REQUIRE(transcriber_handle >= 0);
    struct transcript_t* transcript = nullptr;
    int32_t err = moonshine_transcribe_without_streaming(
        transcriber_handle, wav_data, wav_data_size, wav_sample_rate,
        MOONSHINE_FLAG_SPELLING_MODE, &transcript);
    REQUIRE(err == MOONSHINE_ERROR_NONE);
    REQUIRE(transcript != nullptr);
    REQUIRE(transcript->line_count >= 1);
    const transcript_line_t& line = transcript->lines[0];
    REQUIRE(line.text != nullptr);
    // We expect the matcher (or fusion) to resolve to "a" given the
    // recording is the speaker saying the letter "a".
    CHECK(std::string(line.text) == "a");
    moonshine_free_transcriber(transcriber_handle);
    free(wav_data);
  }
  SUBCASE("tts-synthesizer-valid-options") {
    const auto data_root = find_moonshine_tts_data_dir();
    if (!data_root) {
      MESSAGE("skip: moonshine-tts data directory not found");
      return;
    }
    const std::string model_root_str = data_root->string();
    const moonshine_option_t options[] = {
        {"model_root", model_root_str.c_str()},
        {"kokoro_dir", ""},
        {"piper_voices_dir", ""},
        {"lang", "en_us"},
        {"voice", "kokoro_af_heart"},
        {"speed", "1.0"},
        {"output", "out.wav"},
        {"log_profiling", "true"},
    };
    const uint64_t options_count = sizeof(options) / sizeof(options[0]);
    int32_t tts_synthesizer_handle =
        moonshine_create_tts_synthesizer_from_files("en_us", nullptr, 0,
                                                    options, options_count,
                                                    MOONSHINE_HEADER_VERSION);
    REQUIRE(tts_synthesizer_handle >= 0);
  }
  SUBCASE("tts-synthesizer-per-call-speed-kokoro") {
    const auto data_root = find_moonshine_tts_data_dir();
    if (!data_root) {
      MESSAGE("skip: moonshine-tts data directory not found");
      return;
    }
    const std::string model_root_str = data_root->string();
    const moonshine_option_t create_opts[] = {
        {"model_root", model_root_str.c_str()},
        {"lang", "en_us"},
        {"voice", "kokoro_af_heart"},
        {"speed", "1.0"},
    };
    const int32_t h = moonshine_create_tts_synthesizer_from_files(
        "en_us", nullptr, 0, create_opts,
        static_cast<uint64_t>(sizeof(create_opts) / sizeof(create_opts[0])),
        MOONSHINE_HEADER_VERSION);
    REQUIRE(h >= 0);
    const char* text = "Hello world. Testing per-call speed through the C API.";
    float* a0 = nullptr;
    uint64_t n0 = 0;
    int32_t sr0 = 0;
    REQUIRE(moonshine_text_to_speech(h, text, nullptr, 0, &a0, &n0, &sr0) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(n0 > 2000);
    REQUIRE(a0 != nullptr);
    std::free(a0);
    const moonshine_option_t fast_opts[] = {{"speed", "2.0"}};
    float* a1 = nullptr;
    uint64_t n1 = 0;
    int32_t sr1 = 0;
    REQUIRE(moonshine_text_to_speech(
                h, text, fast_opts,
                static_cast<uint64_t>(sizeof(fast_opts) / sizeof(fast_opts[0])),
                &a1, &n1, &sr1) == MOONSHINE_ERROR_NONE);
    REQUIRE(a1 != nullptr);
    CHECK(n1 < n0);
    std::free(a1);
    float* a2 = nullptr;
    uint64_t n2 = 0;
    int32_t sr2 = 0;
    REQUIRE(moonshine_text_to_speech(h, text, nullptr, 0, &a2, &n2, &sr2) ==
            MOONSHINE_ERROR_NONE);
    CHECK(n2 == n0);
    if (a2 != nullptr) {
      std::free(a2);
    }
    moonshine_free_tts_synthesizer(h);
  }
  SUBCASE("tts-piper-german-from-memory") {
    const std::filesystem::path voices_dir = find_de_piper_voices_dir();
    if (voices_dir.empty()) {
      return;
    }
    // A single-file voice, not the split pair: this exercises supplying a
    // whole model as bytes, which the split form does not do. Voices whose
    // name ends ".model.ort" are one half of a pair and are skipped.
    std::filesystem::path onnx_path;
    for (const auto& ent : std::filesystem::directory_iterator(voices_dir)) {
      if (!ent.is_regular_file()) {
        continue;
      }
      const auto& p = ent.path();
      const std::string name = p.filename().string();
      if (p.extension() == ".ort" &&
          name.find(".model.ort") == std::string::npos &&
          name.find(".weights.ort") == std::string::npos) {
        onnx_path = p;
        break;
      }
    }
    if (onnx_path.empty()) {
      return;
    }
    // Piper keeps the upstream "<voice>.onnx.json" name for the config
    // whatever form the model itself ships in.
    std::filesystem::path json_path = voices_dir;
    json_path /= onnx_path.stem().string() + ".onnx.json";
    std::vector<uint8_t> onnx_data = read_binary_file(onnx_path);
    std::vector<uint8_t> json_data = read_binary_file(json_path);
    if (onnx_data.empty() || json_data.empty()) {
      return;
    }
    std::array<std::string, 2> keys = {std::string("piper/onnx"),
                                       std::string("piper/onnx.json")};
    const char* filenames[2] = {keys[0].c_str(), keys[1].c_str()};
    const uint8_t* mem_ptrs[2] = {onnx_data.data(), json_data.data()};
    const uint64_t mem_sizes[2] = {static_cast<uint64_t>(onnx_data.size()),
                                   static_cast<uint64_t>(json_data.size())};
    const std::string voice_stem = onnx_path.stem().string();
    const auto g2p_root = find_moonshine_tts_data_dir();
    if (!g2p_root) {
      return;
    }
    const std::string g2p_root_str = g2p_root->string();
    const std::string piper_voice = std::string("piper_") + voice_stem;
    const moonshine_option_t opts[] = {
        {"voice", piper_voice.c_str()},
        {"speed", "1.0"},
        {"model_root", g2p_root_str.c_str()},
    };
    int32_t h = moonshine_create_tts_synthesizer_from_memory(
        "de", filenames, 2, mem_ptrs, mem_sizes, opts,
        sizeof(opts) / sizeof(opts[0]), MOONSHINE_HEADER_VERSION);
    REQUIRE(h >= 0);
    float* audio = nullptr;
    uint64_t audio_n = 0;
    int32_t sr = 0;
    REQUIRE(moonshine_text_to_speech(h, "Hallo", nullptr, 0, &audio, &audio_n,
                                     &sr) == MOONSHINE_ERROR_NONE);
    REQUIRE(audio_n > 0);
    REQUIRE(audio != nullptr);
    std::free(audio);
    moonshine_free_tts_synthesizer(h);
  }
}

TEST_CASE("moonshine-phonemes-to-speech-c-api") {
  SUBCASE("invalid-handle") {
    float* audio = nullptr;
    uint64_t n = 0;
    int32_t sr = 0;
    CHECK(moonshine_phonemes_to_speech(-1, "h\u0259\u02c8lo\u028a", nullptr, 0,
                                       &audio, &n,
                                       &sr) == MOONSHINE_ERROR_INVALID_HANDLE);
  }

  SUBCASE("invalid-arguments") {
    const auto data_root = find_moonshine_tts_data_dir();
    if (!data_root) {
      MESSAGE("skip: moonshine-tts data directory not found");
      return;
    }
    const std::string model_root_str = data_root->string();
    const moonshine_option_t create_opts[] = {
        {"model_root", model_root_str.c_str()},
        {"lang", "en_us"},
        {"voice", "kokoro_af_heart"},
    };
    const int32_t h = moonshine_create_tts_synthesizer_from_files(
        "en_us", nullptr, 0, create_opts,
        static_cast<uint64_t>(sizeof(create_opts) / sizeof(create_opts[0])),
        MOONSHINE_HEADER_VERSION);
    REQUIRE(h >= 0);
    float* audio = nullptr;
    uint64_t n = 0;
    int32_t sr = 0;
    // NULL phonemes / output pointers are rejected before synthesis.
    CHECK(
        moonshine_phonemes_to_speech(h, nullptr, nullptr, 0, &audio, &n, &sr) ==
        MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(moonshine_phonemes_to_speech(h, "h\u0259\u02c8lo\u028a", nullptr, 0,
                                       nullptr, &n, &sr) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    moonshine_free_tts_synthesizer(h);
  }

  SUBCASE("kokoro-matches-text-to-speech") {
    const auto data_root = find_moonshine_tts_data_dir();
    if (!data_root) {
      MESSAGE("skip: moonshine-tts data directory not found");
      return;
    }
    const std::string root_str = data_root->string();
    const moonshine_option_t create_opts[] = {
        {"model_root", root_str.c_str()},
        {"lang", "en_us"},
        {"voice", "kokoro_af_heart"},
        {"speed", "1.0"},
    };
    const int32_t tts = moonshine_create_tts_synthesizer_from_files(
        "en_us", nullptr, 0, create_opts,
        static_cast<uint64_t>(sizeof(create_opts) / sizeof(create_opts[0])),
        MOONSHINE_HEADER_VERSION);
    REQUIRE(tts >= 0);

    const moonshine_option_t g2p_opts[] = {{"g2p_root", root_str.c_str()}};
    const int32_t g2p = moonshine_create_grapheme_to_phonemizer_from_files(
        "en_us", nullptr, 0, g2p_opts,
        static_cast<uint64_t>(sizeof(g2p_opts) / sizeof(g2p_opts[0])),
        MOONSHINE_HEADER_VERSION);
    REQUIRE(g2p >= 0);

    const char* text = "Hello world, this is a phoneme test.";

    // text -> IPA phonemes.
    const char* ipa = nullptr;
    uint64_t ipa_count = 0;
    REQUIRE(moonshine_text_to_phonemes(g2p, text, nullptr, 0, &ipa,
                                       &ipa_count) == MOONSHINE_ERROR_NONE);
    REQUIRE(ipa != nullptr);
    REQUIRE(ipa_count > 1);

    // phonemes -> speech.
    float* audio_ph = nullptr;
    uint64_t n_ph = 0;
    int32_t sr_ph = 0;
    REQUIRE(moonshine_phonemes_to_speech(tts, ipa, nullptr, 0, &audio_ph, &n_ph,
                                         &sr_ph) == MOONSHINE_ERROR_NONE);
    CHECK(sr_ph == 24000);
    CHECK(n_ph > 2000);
    REQUIRE(audio_ph != nullptr);

    // text -> speech via the full pipeline should be equivalent, since the
    // synthesizer runs the same en_us G2P internally.
    float* audio_txt = nullptr;
    uint64_t n_txt = 0;
    int32_t sr_txt = 0;
    REQUIRE(moonshine_text_to_speech(tts, text, nullptr, 0, &audio_txt, &n_txt,
                                     &sr_txt) == MOONSHINE_ERROR_NONE);
    REQUIRE(audio_txt != nullptr);
    CHECK(sr_txt == sr_ph);
    CHECK(n_txt == n_ph);
    if (n_txt == n_ph) {
      double max_abs_diff = 0.0;
      for (uint64_t i = 0; i < n_ph; ++i) {
        max_abs_diff = std::max(
            max_abs_diff,
            static_cast<double>(std::fabs(audio_ph[i] - audio_txt[i])));
      }
      CHECK(max_abs_diff < 1e-3);
    }

    // A faster per-call speed should shorten the phoneme-driven output too.
    const moonshine_option_t fast_opts[] = {{"speed", "2.0"}};
    float* audio_fast = nullptr;
    uint64_t n_fast = 0;
    int32_t sr_fast = 0;
    REQUIRE(moonshine_phonemes_to_speech(
                tts, ipa, fast_opts,
                static_cast<uint64_t>(sizeof(fast_opts) / sizeof(fast_opts[0])),
                &audio_fast, &n_fast, &sr_fast) == MOONSHINE_ERROR_NONE);
    CHECK(n_fast < n_ph);

    std::free(audio_ph);
    std::free(audio_txt);
    if (audio_fast != nullptr) {
      std::free(audio_fast);
    }
    free_phonemes_output(ipa);
    moonshine_free_grapheme_to_phonemizer(g2p);
    moonshine_free_tts_synthesizer(tts);
  }
}

TEST_CASE("grapheme-to-phonemizer-c-api") {
  SUBCASE("create-invalid-filenames-pointer") {
    const moonshine_option_t opts[] = {
        {"g2p_root", "."},
    };
    const int32_t h = moonshine_create_grapheme_to_phonemizer_from_files(
        "en_us", nullptr, 1, opts, sizeof(opts) / sizeof(opts[0]),
        MOONSHINE_HEADER_VERSION);
    CHECK(h == MOONSHINE_ERROR_INVALID_ARGUMENT);
  }

  SUBCASE("text-to-phonemes-invalid-handle") {
    const char* ipa = nullptr;
    uint64_t n = 0;
    CHECK(moonshine_text_to_phonemes(-1, "a", nullptr, 0, &ipa, &n) ==
          MOONSHINE_ERROR_INVALID_HANDLE);
  }

  SUBCASE("text-to-phonemes-invalid-arguments") {
    const auto data_root = find_moonshine_tts_data_dir();
    if (!data_root) {
      MESSAGE(
          "skip: moonshine-tts data directory not found (run from test-assets "
          "or set cwd)");
      return;
    }
    const std::string g2p_root_str = data_root->string();
    const moonshine_option_t opts[] = {
        {"g2p_root", g2p_root_str.c_str()},
    };
    int32_t h = moonshine_create_grapheme_to_phonemizer_from_files(
        "en_us", nullptr, 0, opts, sizeof(opts) / sizeof(opts[0]),
        MOONSHINE_HEADER_VERSION);
    REQUIRE(h >= 0);
    const char* ipa = nullptr;
    uint64_t phoneme_count = 0;
    CHECK(moonshine_text_to_phonemes(h, nullptr, nullptr, 0, &ipa,
                                     &phoneme_count) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(moonshine_text_to_phonemes(h, "hi", nullptr, 0, nullptr,
                                     &phoneme_count) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    moonshine_free_grapheme_to_phonemizer(h);
  }

  SUBCASE("rule-based-languages-smoke") {
    const auto data_root = find_moonshine_tts_data_dir();
    if (!data_root) {
      MESSAGE("skip: moonshine-tts data directory not found");
      return;
    }
    static const GraphemePhonemizerLangCase kCases[] = {
        {"en_us", "Hello", "en_us/dict_filtered_heteronyms.tsv"},
        {"es_mx", "hola", nullptr},
        {"de", "Hallo", "de/dict.tsv"},
        {"fr", "bonjour", "fr/dict.tsv"},
        {"nl", "hallo", "nl/dict.tsv"},
        {"it", "ciao", "it/dict.tsv"},
        {"ru", "\xd0\xbf\xd1\x80\xd0\xb8\xd0\xb2\xd0\xb5\xd1\x82",
         "ru/dict.tsv"},
        {"vi", "xin", "vi/dict.tsv"},
        {"ko", "\xec\x95\x88\xeb\x85\x95", "ko/dict.tsv"},
        {"pt_br", "ol\xc3\xa1", "pt_br/dict.tsv"},
        {"pt_pt", "ol\xc3\xa1", "pt_pt/dict.tsv"},
        {"tr", "merhaba", nullptr},
        {"uk", "\xd0\xbf\xd1\x80\xd1\x96\xd0\xb2\xd1\x96\xd1\x82", nullptr},
        {"hi",
         "\xe0\xa4\xa8\xe0\xa4\xae\xe0\xa4\xb8\xe0\xa5\x8d\xe0\xa4\xa4\xe0\xa5"
         "\x87",
         "hi/dict.tsv"},
    };
    namespace fs = std::filesystem;
    for (const auto& c : kCases) {
      if (c.required_relative_file != nullptr &&
          !fs::is_regular_file(*data_root / c.required_relative_file)) {
        MESSAGE("skip language ", c.language, ": missing ",
                c.required_relative_file);
        continue;
      }
      INFO("grapheme phonemizer language: " << c.language);
      grapheme_phonemizer_smoke(*data_root, c.language, c.text);
    }
  }

  SUBCASE("chinese-when-onnx-bundle-present") {
    const auto data_root = find_moonshine_tts_data_dir();
    if (!data_root) {
      MESSAGE("skip: moonshine-tts data directory not found");
      return;
    }
    namespace fs = std::filesystem;
    const fs::path zh_meta =
        *data_root / "zh_hans" / "roberta_chinese_base_upos_onnx" / "meta.json";
    const fs::path zh_dict = *data_root / "zh_hans" / "dict.tsv";
    if (!fs::is_regular_file(zh_meta) || !fs::is_regular_file(zh_dict)) {
      MESSAGE("skip: Chinese ONNX bundle or dict not present");
      return;
    }
    grapheme_phonemizer_smoke(*data_root, "zh", "\xe4\xbd\xa0\xe5\xa5\xbd");
  }

  SUBCASE("japanese-when-onnx-bundle-present") {
    const auto data_root = find_moonshine_tts_data_dir();
    if (!data_root) {
      MESSAGE("skip: moonshine-tts data directory not found");
      return;
    }
    namespace fs = std::filesystem;
    const fs::path ja_meta =
        *data_root / "ja" / "roberta_japanese_char_luw_upos_onnx" / "meta.json";
    const fs::path ja_dict = *data_root / "ja" / "dict.tsv";
    if (!fs::is_regular_file(ja_meta) || !fs::is_regular_file(ja_dict)) {
      MESSAGE("skip: Japanese ONNX bundle or dict not present");
      return;
    }
    grapheme_phonemizer_smoke(
        *data_root, "ja",
        "\xe3\x81\x93\xe3\x82\x93\xe3\x81\xab\xe3\x81\xa1\xe3\x81\xaf");
  }

  SUBCASE("arabic-when-onnx-bundle-present") {
    const auto data_root = find_moonshine_tts_data_dir();
    if (!data_root) {
      MESSAGE("skip: moonshine-tts data directory not found");
      return;
    }
    namespace fs = std::filesystem;
    const fs::path ar_meta =
        *data_root / "ar_msa" / "arabertv02_tashkeel_fadel_onnx" / "meta.json";
    const fs::path ar_dict = *data_root / "ar_msa" / "dict.tsv";
    if (!fs::is_regular_file(ar_meta) || !fs::is_regular_file(ar_dict)) {
      MESSAGE("skip: Arabic ONNX bundle or dict not present");
      return;
    }
    grapheme_phonemizer_smoke(*data_root, "ar_msa",
                              "\xd9\x85\xd8\xb1\xd8\xad\xd8\xa8\xd8\xa7");
  }
}

TEST_CASE("moonshine-tts-split-utterances-c-api") {
  SUBCASE("null-output-pointer") {
    CHECK(moonshine_tts_split_utterances("en_us", "Hi.", nullptr, 0, nullptr) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
  }
  SUBCASE("abbreviations-do-not-split") {
    char* json = nullptr;
    REQUIRE(moonshine_tts_split_utterances(
                "en_us", "Dr. Smith arrived. We left.", nullptr, 0, &json) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(json != nullptr);
    const std::string out(json);
    moonshine_free_buffer(json);
    CHECK(out == "[\"Dr. Smith arrived.\",\"We left.\"]");
  }
  SUBCASE("empty-input-gives-empty-array") {
    char* json = nullptr;
    REQUIRE(moonshine_tts_split_utterances("en_us", "   ", nullptr, 0, &json) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(json != nullptr);
    const std::string out(json);
    moonshine_free_buffer(json);
    CHECK(out == "[]");
  }
  SUBCASE("colon-split-can-be-disabled") {
    const moonshine_option_t opts[] = {{"split_on_colon", "false"}};
    char* json = nullptr;
    REQUIRE(moonshine_tts_split_utterances("en_us", "Warning: hot.", opts, 1,
                                           &json) == MOONSHINE_ERROR_NONE);
    REQUIRE(json != nullptr);
    const std::string out(json);
    moonshine_free_buffer(json);
    CHECK(out == "[\"Warning: hot.\"]");
  }
}

TEST_CASE("moonshine-tts-streaming-c-api") {
  SUBCASE("invalid-handles") {
    CHECK(moonshine_tts_push_text(-1, "hi") == MOONSHINE_ERROR_INVALID_HANDLE);
    CHECK(moonshine_tts_flush(-1) == MOONSHINE_ERROR_INVALID_HANDLE);
    CHECK(moonshine_tts_end_input(-1) == MOONSHINE_ERROR_INVALID_HANDLE);
    CHECK(moonshine_tts_cancel(-1) == MOONSHINE_ERROR_INVALID_HANDLE);
    const tts_chunk_t* chunk = nullptr;
    CHECK(moonshine_tts_next_chunk(-1, 0, &chunk) ==
          MOONSHINE_ERROR_INVALID_HANDLE);
    CHECK(chunk == nullptr);
  }

  const auto data_root = find_moonshine_tts_data_dir();
  if (!data_root) {
    MESSAGE("skip: moonshine-tts data directory not found");
    return;
  }
  const std::string model_root_str = data_root->string();
  const moonshine_option_t create_opts[] = {
      {"model_root", model_root_str.c_str()},
      {"lang", "en_us"},
      {"voice", "kokoro_af_heart"},
  };
  const int32_t h = moonshine_create_tts_synthesizer_from_files(
      "en_us", nullptr, 0, create_opts,
      static_cast<uint64_t>(sizeof(create_opts) / sizeof(create_opts[0])),
      MOONSHINE_HEADER_VERSION);
  REQUIRE(h >= 0);

  SUBCASE("reserved-flags-are-rejected") {
    const tts_chunk_t* chunk = nullptr;
    CHECK(moonshine_tts_next_chunk(h, 1, &chunk) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
  }

  SUBCASE("incremental-push-waits-for-a-complete-sentence") {
    const tts_chunk_t* chunk = nullptr;
    // A fragment is not enough to synthesize: prosody needs the whole clause.
    REQUIRE(moonshine_tts_push_text(h, "Hello ") == MOONSHINE_ERROR_NONE);
    CHECK(moonshine_tts_next_chunk(h, 0, &chunk) == MOONSHINE_TTS_NEED_TEXT);
    CHECK(chunk == nullptr);
    // The terminator plus following whitespace completes it.
    REQUIRE(moonshine_tts_push_text(h, "there. ") == MOONSHINE_ERROR_NONE);
    REQUIRE(moonshine_tts_next_chunk(h, 0, &chunk) == MOONSHINE_ERROR_NONE);
    REQUIRE(chunk != nullptr);
    CHECK(chunk->audio_data != nullptr);
    CHECK(chunk->audio_data_count > 1000);
    CHECK(chunk->sample_rate == 24000);
    CHECK(chunk->utterance_id == 1);
    // Text is attributed to the first chunk of an utterance. A later chunk cut
    // on acoustic frames covers no knowable span of characters, so it carries
    // none, and only the last is marked final.
    CHECK(std::string(chunk->text) == "Hello there.");
    moonshine_tts_end_input(h);
    int8_t last_final = chunk->is_final;
    for (int i = 0; i < 32; ++i) {
      const tts_chunk_t* more = nullptr;
      if (moonshine_tts_next_chunk(h, 0, &more) != MOONSHINE_ERROR_NONE) {
        break;
      }
      REQUIRE(more != nullptr);
      CHECK(more->utterance_id == 1);
      last_final = more->is_final;
    }
    CHECK(last_final == 1);
  }

  SUBCASE("flush-forces-an-unterminated-fragment-out") {
    const tts_chunk_t* chunk = nullptr;
    REQUIRE(moonshine_tts_push_text(h, "no terminator") ==
            MOONSHINE_ERROR_NONE);
    CHECK(moonshine_tts_next_chunk(h, 0, &chunk) == MOONSHINE_TTS_NEED_TEXT);
    REQUIRE(moonshine_tts_flush(h) == MOONSHINE_ERROR_NONE);
    REQUIRE(moonshine_tts_next_chunk(h, 0, &chunk) == MOONSHINE_ERROR_NONE);
    REQUIRE(chunk != nullptr);
    CHECK(chunk->audio_data_count > 0);
    moonshine_tts_cancel(h);
  }

  SUBCASE("end-of-stream-after-the-queue-drains") {
    REQUIRE(moonshine_tts_push_text(h, "One. Two.") == MOONSHINE_ERROR_NONE);
    REQUIRE(moonshine_tts_end_input(h) == MOONSHINE_ERROR_NONE);
    std::vector<uint64_t> ids;
    for (int i = 0; i < 32; ++i) {
      const tts_chunk_t* chunk = nullptr;
      const int32_t status = moonshine_tts_next_chunk(h, 0, &chunk);
      if (status == MOONSHINE_TTS_END_OF_STREAM) {
        break;
      }
      REQUIRE(status == MOONSHINE_ERROR_NONE);
      REQUIRE(chunk != nullptr);
      ids.push_back(chunk->utterance_id);
    }
    REQUIRE(ids.size() >= 2);
    CHECK(ids.front() == 1);
    CHECK(ids.back() == 2);
    // Draining returns the synthesizer to idle without anything to release.
    CHECK(moonshine_tts_is_streaming(h) == 0);
  }

  SUBCASE("streamed-audio-is-the-same-length-and-level-as-the-whole-render") {
    const char* text =
        "The old lighthouse stood alone against the crashing waves.";
    // Both sides have to be raw for this to compare like with like. With
    // normalization on they are scaled by different things on purpose: the
    // whole render by its own peak, which streaming cannot know before it has
    // decoded everything, and the stream by its voice's measured level.
    const moonshine_option_t plain_opts[] = {
        {"model_root", model_root_str.c_str()},
        {"lang", "en_us"},
        {"voice", "kokoro_af_heart"},
        {"normalize_audio", "false"},
    };
    const int32_t plain_h = moonshine_create_tts_synthesizer_from_files(
        "en_us", nullptr, 0, plain_opts,
        sizeof(plain_opts) / sizeof(plain_opts[0]), MOONSHINE_HEADER_VERSION);
    REQUIRE(plain_h >= 0);
    float* whole = nullptr;
    uint64_t whole_n = 0;
    int32_t whole_sr = 0;
    REQUIRE(moonshine_text_to_speech(plain_h, text, nullptr, 0, &whole,
                                     &whole_n,
                                     &whole_sr) == MOONSHINE_ERROR_NONE);
    REQUIRE(whole != nullptr);

    REQUIRE(moonshine_tts_push_text(plain_h, text) == MOONSHINE_ERROR_NONE);
    REQUIRE(moonshine_tts_end_input(plain_h) == MOONSHINE_ERROR_NONE);
    std::vector<float> streamed;
    for (int i = 0; i < 64; ++i) {
      const tts_chunk_t* chunk = nullptr;
      if (moonshine_tts_next_chunk(plain_h, 0, &chunk) !=
          MOONSHINE_ERROR_NONE) {
        break;
      }
      streamed.insert(streamed.end(), chunk->audio_data,
                      chunk->audio_data + chunk->audio_data_count);
    }
    moonshine_free_tts_synthesizer(plain_h);

    // Not a sample-for-sample comparison. The decoder normalizes over whatever
    // span it is given and its excitation restarts per chunk, so a chunked
    // render is a different render of the same words. What has to hold is that
    // it lasts about as long and comes out at the same level. Linux x86_64
    // ORT can differ from Apple Silicon by one 50 ms Kokoro frame (1200
    // samples at 24 kHz); that is still the same utterance.
    const auto whole_len = static_cast<long long>(whole_n);
    const auto stream_len = static_cast<long long>(streamed.size());
    REQUIRE(std::llabs(stream_len - whole_len) <= 1200);
    const uint64_t n =
        std::min(whole_n, static_cast<uint64_t>(streamed.size()));
    double whole_energy = 0.0;
    double streamed_energy = 0.0;
    for (uint64_t i = 0; i < n; ++i) {
      whole_energy += static_cast<double>(whole[i]) * whole[i];
      streamed_energy += static_cast<double>(streamed[i]) * streamed[i];
    }
    const double ratio_db = 10.0 * std::log10(std::max(streamed_energy, 1e-12) /
                                              std::max(whole_energy, 1e-12));
    CHECK(std::fabs(ratio_db) < 1.5);
    std::free(whole);
  }

  SUBCASE("normalizing-a-stream-applies-one-gain-to-the-whole-utterance") {
    // Streaming stands in for peak normalization with a level measured offline
    // for the voice. The point of measuring it per voice rather than per chunk
    // is that one gain covers the utterance, so it must scale peak and RMS by
    // the same amount; a per-chunk gain would move them apart.
    const char* text =
        "The old lighthouse stood alone against the crashing waves.";
    const auto stream_levels = [&text](int32_t handle) {
      REQUIRE(moonshine_tts_push_text(handle, text) == MOONSHINE_ERROR_NONE);
      REQUIRE(moonshine_tts_end_input(handle) == MOONSHINE_ERROR_NONE);
      double peak = 0.0;
      double sum_sq = 0.0;
      size_t count = 0;
      for (int i = 0; i < 64; ++i) {
        const tts_chunk_t* chunk = nullptr;
        if (moonshine_tts_next_chunk(handle, 0, &chunk) !=
            MOONSHINE_ERROR_NONE) {
          break;
        }
        for (uint64_t s = 0; s < chunk->audio_data_count; ++s) {
          const double x = chunk->audio_data[s];
          peak = std::max(peak, std::fabs(x));
          sum_sq += x * x;
        }
        count += chunk->audio_data_count;
      }
      REQUIRE(count > 0);
      return std::pair<double, double>{peak, std::sqrt(sum_sq / double(count))};
    };

    const moonshine_option_t plain_opts[] = {
        {"model_root", model_root_str.c_str()},
        {"lang", "en_us"},
        {"voice", "kokoro_af_heart"},
        {"normalize_audio", "false"},
    };
    const int32_t plain_h = moonshine_create_tts_synthesizer_from_files(
        "en_us", nullptr, 0, plain_opts,
        sizeof(plain_opts) / sizeof(plain_opts[0]), MOONSHINE_HEADER_VERSION);
    REQUIRE(plain_h >= 0);
    const auto [raw_peak, raw_rms] = stream_levels(plain_h);
    moonshine_free_tts_synthesizer(plain_h);

    const auto [norm_peak, norm_rms] = stream_levels(h);

    // Normalizing brings af_heart up, so the gain is above one.
    CHECK(norm_peak > raw_peak);
    const double peak_gain_db = 20.0 * std::log10(norm_peak / raw_peak);
    const double rms_gain_db = 20.0 * std::log10(norm_rms / raw_rms);
    CHECK(std::fabs(peak_gain_db - rms_gain_db) < 0.5);
  }

  SUBCASE("a-long-utterance-is-cut-into-growing-chunks") {
    REQUIRE(moonshine_tts_push_text(
                h,
                "The old lighthouse stood alone against the crashing waves of "
                "the north sea, its lamp turning slowly through the fog.") ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(moonshine_tts_end_input(h) == MOONSHINE_ERROR_NONE);
    std::vector<uint64_t> sizes;
    for (int i = 0; i < 64; ++i) {
      const tts_chunk_t* chunk = nullptr;
      if (moonshine_tts_next_chunk(h, 0, &chunk) != MOONSHINE_ERROR_NONE) {
        break;
      }
      sizes.push_back(chunk->audio_data_count);
    }
    // Only where the Kokoro stage models are installed. Elsewhere this is one
    // chunk for the sentence, which is still a valid way to stream it.
    if (sizes.size() > 2) {
      // The first chunk is the only one that delays playback, so it is short;
      // later ones grow, which is what keeps the decoder's level steady.
      CHECK(sizes.front() < sizes[1]);
      CHECK(sizes[1] < sizes[2]);
      CHECK(sizes.front() < 24000);
    }
  }

  SUBCASE("cancel-drops-queued-text-and-returns-to-idle") {
    REQUIRE(moonshine_tts_push_text(h, "Discard this. And this. ") ==
            MOONSHINE_ERROR_NONE);
    CHECK(moonshine_tts_is_streaming(h) == 1);
    REQUIRE(moonshine_tts_cancel(h) == MOONSHINE_ERROR_NONE);
    CHECK(moonshine_tts_is_streaming(h) == 0);
    const tts_chunk_t* chunk = nullptr;
    // The consumer is told the reply was abandoned rather than left to guess
    // from the audio stopping, and is told once.
    CHECK(moonshine_tts_next_chunk(h, 0, &chunk) == MOONSHINE_TTS_CANCELLED);
    CHECK(chunk == nullptr);
    CHECK(moonshine_tts_next_chunk(h, 0, &chunk) == MOONSHINE_TTS_NEED_TEXT);
    REQUIRE(moonshine_tts_push_text(h, "Say this instead. ") ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(moonshine_tts_next_chunk(h, 0, &chunk) == MOONSHINE_ERROR_NONE);
    REQUIRE(chunk != nullptr);
    CHECK(chunk->audio_data_count > 0);
    moonshine_tts_cancel(h);
  }

  SUBCASE("cancelling-an-idle-synthesizer-reports-nothing") {
    // Cancel is safe to call unconditionally, so a caller that cancels on every
    // turn boundary must not see a phantom interruption.
    REQUIRE(moonshine_tts_cancel(h) == MOONSHINE_ERROR_NONE);
    const tts_chunk_t* chunk = nullptr;
    CHECK(moonshine_tts_next_chunk(h, 0, &chunk) == MOONSHINE_TTS_NEED_TEXT);
  }

  SUBCASE("cancel-part-way-through-a-reply-reports-cancelled") {
    REQUIRE(moonshine_tts_push_text(
                h,
                "The old lighthouse stood alone against the crashing waves of "
                "the north sea, its lamp turning slowly through the fog. ") ==
            MOONSHINE_ERROR_NONE);
    const tts_chunk_t* chunk = nullptr;
    REQUIRE(moonshine_tts_next_chunk(h, 0, &chunk) == MOONSHINE_ERROR_NONE);
    REQUIRE(chunk != nullptr);
    CHECK(chunk->is_final == 0);
    REQUIRE(moonshine_tts_cancel(h) == MOONSHINE_ERROR_NONE);
    CHECK(moonshine_tts_next_chunk(h, 0, &chunk) == MOONSHINE_TTS_CANCELLED);
    CHECK(chunk == nullptr);
  }

  SUBCASE("the-cancelled-status-has-a-name") {
    CHECK(std::string(moonshine_error_to_string(MOONSHINE_TTS_CANCELLED)) !=
          "Unknown error");
  }

  SUBCASE("a-one-shot-call-is-refused-while-streaming") {
    REQUIRE(moonshine_tts_push_text(h, "Mid reply. ") == MOONSHINE_ERROR_NONE);
    float* audio = nullptr;
    uint64_t count = 0;
    int32_t rate = 0;
    CHECK(moonshine_text_to_speech(h, "Something else.", nullptr, 0, &audio,
                                   &count, &rate) == MOONSHINE_ERROR_BUSY);
    CHECK(audio == nullptr);
    // Cancelling the reply hands the model back.
    REQUIRE(moonshine_tts_cancel(h) == MOONSHINE_ERROR_NONE);
    REQUIRE(moonshine_text_to_speech(h, "Something else.", nullptr, 0, &audio,
                                     &count, &rate) == MOONSHINE_ERROR_NONE);
    CHECK(count > 0);
    std::free(audio);
  }

  SUBCASE("freeing-one-synthesizer-leaves-another-streaming") {
    REQUIRE(moonshine_tts_push_text(h, "Still here. ") == MOONSHINE_ERROR_NONE);
    const int32_t h2 = moonshine_create_tts_synthesizer_from_files(
        "en_us", nullptr, 0, create_opts,
        static_cast<uint64_t>(sizeof(create_opts) / sizeof(create_opts[0])),
        MOONSHINE_HEADER_VERSION);
    REQUIRE(h2 >= 0);
    moonshine_free_tts_synthesizer(h2);
    CHECK(moonshine_tts_is_streaming(h) == 1);
    const tts_chunk_t* chunk = nullptr;
    CHECK(moonshine_tts_next_chunk(h, 0, &chunk) == MOONSHINE_ERROR_NONE);
    moonshine_tts_cancel(h);
  }

  moonshine_free_tts_synthesizer(h);
}

TEST_CASE("moonshine-tts-g2p-dependency-api") {
  SUBCASE("null-output-pointer") {
    CHECK(moonshine_get_g2p_dependencies("en_us", nullptr, 0, nullptr) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(moonshine_get_tts_dependencies("en_us", nullptr, 0, nullptr) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(moonshine_get_tts_voices("en_us", nullptr, 0, nullptr) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
  }

  SUBCASE("options-count-without-options-pointer") {
    char* out = nullptr;
    CHECK(moonshine_get_g2p_dependencies("en_us", nullptr, 1, &out) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(moonshine_get_tts_dependencies("en_us", nullptr, 1, &out) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(moonshine_get_tts_voices("en_us", nullptr, 1, &out) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
  }

  SUBCASE("g2p-empty-means-all-languages") {
    char* out = nullptr;
    REQUIRE(moonshine_get_g2p_dependencies("", nullptr, 0, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string csv(out);
    CHECK(csv.find("de/dict.tsv") != std::string::npos);
    CHECK(csv.find("en_us/dict_filtered_heteronyms.tsv") != std::string::npos);
    CHECK(csv.find("fr/adj.csv") != std::string::npos);
    // Chinese ships as a split pair, so both halves must be listed.
    CHECK(csv.find("zh_hans/roberta_chinese_base_upos_onnx/model.model.ort") !=
          std::string::npos);
    CHECK(
        csv.find("zh_hans/roberta_chinese_base_upos_onnx/model.weights.ort") !=
        std::string::npos);
    CHECK(csv.find("zh_hans/roberta_chinese_base_upos_onnx/model.onnx") ==
          std::string::npos);
    CHECK(csv.find("ja/roberta_japanese_char_luw_upos_onnx/model.ort") !=
          std::string::npos);
    std::free(out);
  }

  SUBCASE("g2p-arabic-lists-both-halves-of-the-split-model") {
    char* out = nullptr;
    REQUIRE(moonshine_get_g2p_dependencies("ar_msa", nullptr, 0, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string csv(out);
    CHECK(csv.find("ar_msa/arabertv02_tashkeel_fadel_onnx/model.model.ort") !=
          std::string::npos);
    CHECK(csv.find("ar_msa/arabertv02_tashkeel_fadel_onnx/model.weights.ort") !=
          std::string::npos);
    CHECK(csv.find("ar_msa/arabertv02_tashkeel_fadel_onnx/model.onnx") ==
          std::string::npos);
    std::free(out);
  }

  SUBCASE("g2p-french-lists-pos-csv-files-not-directory-prefix") {
    char* out = nullptr;
    REQUIRE(moonshine_get_g2p_dependencies("fr", nullptr, 0, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string csv(out);
    CHECK(csv.find("fr/dict.tsv") != std::string::npos);
    CHECK(csv.find("fr/noun.csv") != std::string::npos);
    CHECK(csv.find("fr/verb.csv") != std::string::npos);
    CHECK(csv.compare(0, 3, "fr,") != 0);
    CHECK(csv.find(",fr,") == std::string::npos);
    std::free(out);
  }

  SUBCASE("g2p-single-language") {
    char* out = nullptr;
    REQUIRE(moonshine_get_g2p_dependencies("de", nullptr, 0, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    CHECK(std::string(out) == "de/dict.tsv");
    std::free(out);
  }

  SUBCASE("g2p-unsupported-language") {
    char* out = nullptr;
    CHECK(moonshine_get_g2p_dependencies("zzz_not_a_supported_language",
                                         nullptr, 0, &out) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(out == nullptr);
  }

  SUBCASE("g2p-multiple-languages") {
    char* out = nullptr;
    REQUIRE(moonshine_get_g2p_dependencies("en_us, de", nullptr, 0, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string csv(out);
    CHECK(csv.find("en_us/dict_filtered_heteronyms.tsv") != std::string::npos);
    CHECK(csv.find("de/dict.tsv") != std::string::npos);
    CHECK(csv.find(',') != std::string::npos);
    std::free(out);
  }

  SUBCASE("g2p-appends-override-key-when-option-set") {
    const moonshine_option_t opts[] = {
        {"oov_onnx_override", "/nonexistent/oov.onnx"},
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_g2p_dependencies("de", opts, 1, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    CHECK(std::string(out).find("oov_onnx_override") != std::string::npos);
    std::free(out);
  }

  SUBCASE("tts-json-single-language") {
    char* out = nullptr;
    REQUIRE(moonshine_get_tts_dependencies("en_us", nullptr, 0, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.size() >= 2);
    CHECK(json.find("\"groups\"") != std::string::npos);
    // Kokoro ships as two stages, each a split ORT pair, and no
    // whole-utterance model: running the stages back to back is what serves
    // that path now, so fetching one as well would double the download.
    CHECK(json.find("\"kokoro/prosody.model.ort\"") != std::string::npos);
    CHECK(json.find("\"kokoro/prosody.weights.ort\"") != std::string::npos);
    CHECK(json.find("\"kokoro/decoder.model.ort\"") != std::string::npos);
    CHECK(json.find("\"kokoro/decoder.weights.ort\"") != std::string::npos);
    CHECK(json.find("\"kokoro/model.model.ort\"") == std::string::npos);
    CHECK(json.find("\"kokoro/model.weights.ort\"") == std::string::npos);
    CHECK(json.find("\"kokoro/model.ort\"") == std::string::npos);
    CHECK(json.find("\"en_us/dict_filtered_heteronyms.tsv\"") !=
          std::string::npos);
    std::free(out);
  }

  SUBCASE("tts-empty-all-languages-json") {
    char* out = nullptr;
    REQUIRE(moonshine_get_tts_dependencies("", nullptr, 0, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"groups\"") != std::string::npos);
    CHECK(json.find("\"kokoro/prosody.model.ort\"") != std::string::npos);
    CHECK(json.find("\"kokoro/decoder.model.ort\"") != std::string::npos);
    std::free(out);
  }

  SUBCASE("tts-unsupported-language") {
    char* out = nullptr;
    CHECK(moonshine_get_tts_dependencies("zzz_not_a_supported_language",
                                         nullptr, 0, &out) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(out == nullptr);
  }

  SUBCASE("tts-multiple-languages") {
    char* out = nullptr;
    REQUIRE(moonshine_get_tts_dependencies("en_us,de", nullptr, 0, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"de/dict.tsv\"") != std::string::npos);
    CHECK(json.find("\"en_us/dict_filtered_heteronyms.tsv\"") !=
          std::string::npos);
    CHECK(json.find("piper-voices") != std::string::npos);
    std::free(out);
  }

  SUBCASE("tts-piper-engine-on-en_us") {
    const moonshine_option_t opts[] = {
        {"voice", "piper_en_us-test-voice"},
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_tts_dependencies("en_us", opts, 1, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("piper-voices") != std::string::npos);
    CHECK(json.find("kokoro/model") == std::string::npos);
    std::free(out);
  }

  SUBCASE("tts-kokoro-engine-on-fr") {
    const moonshine_option_t opts[] = {
        {"voice", "kokoro_ff_siwis"},
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_tts_dependencies("fr", opts, 1, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"kokoro/prosody.model.ort\"") != std::string::npos);
    CHECK(json.find("\"kokoro/decoder.model.ort\"") != std::string::npos);
    CHECK(json.find("piper-voices") == std::string::npos);
    std::free(out);
  }

  SUBCASE("tts-explicit-piper-onnx-map-keys") {
    const moonshine_option_t opts[] = {
        {"voice", "piper_custom"},
        {"piper_onnx", "custom/model.ort"},
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_tts_dependencies("de", opts, 2, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"piper/onnx\"") != std::string::npos);
    CHECK(json.find("\"piper/onnx.json\"") != std::string::npos);
    std::free(out);
  }

  SUBCASE("tts-piper-voice-selects-split-ort-pair") {
    const moonshine_option_t opts[] = {
        {"voice", "piper_de_DE-thorsten-medium"},
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_tts_dependencies("de", opts, 1, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    // A voice ships as two stages, and a quantized one has each of those as a
    // split ORT pair. The config keeps the ``.onnx.json`` name whatever form
    // the model takes.
    CHECK(json.find("de_DE-thorsten-medium.upstream.model.ort") !=
          std::string::npos);
    CHECK(json.find("de_DE-thorsten-medium.upstream.weights.ort") !=
          std::string::npos);
    CHECK(json.find("de_DE-thorsten-medium.generator.model.ort") !=
          std::string::npos);
    CHECK(json.find("de_DE-thorsten-medium.generator.weights.ort") !=
          std::string::npos);
    CHECK(json.find("\"de_DE-thorsten-medium.model.ort\"") ==
          std::string::npos);
    CHECK(json.find("de_DE-thorsten-medium.onnx.json") != std::string::npos);
    std::free(out);
  }

  SUBCASE("tts-piper-unquantized-voice-selects-single-ort") {
    const moonshine_option_t opts[] = {
        {"voice", "piper_en_US-saikat"},
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_tts_dependencies("en_us", opts, 1, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("en_US-saikat.upstream.ort") != std::string::npos);
    CHECK(json.find("en_US-saikat.generator.ort") != std::string::npos);
    CHECK(json.find("en_US-saikat.upstream.model.ort") == std::string::npos);
    std::free(out);
  }

  SUBCASE("tts-voices-json-object-en_us") {
    const auto data_root = find_moonshine_tts_data_dir();
    if (!data_root) {
      MESSAGE("skip: moonshine-tts data directory not found");
      return;
    }
    const std::string g2p_root_str = data_root->string();
    const moonshine_option_t opts[] = {
        {"g2p_root", g2p_root_str.c_str()},
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_tts_voices("en_us", opts, 1, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.front() == '{');
    CHECK(json.back() == '}');
    CHECK(json.find("\"en_us\"") != std::string::npos);
    CHECK(json.find("\"kokoro_af_heart\"") != std::string::npos);
    CHECK(json.find("\"state\":\"found\"") != std::string::npos);
    std::free(out);
  }

  SUBCASE("tts-voices-kokoro-reports-missing-without-assets") {
    const moonshine_option_t opts[] = {
        {"g2p_root", "/tmp"},
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_tts_voices("en_us", opts, 1, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"state\":\"missing\"") != std::string::npos);
    CHECK(json.find("\"kokoro_af_heart\"") != std::string::npos);
    std::free(out);
  }

  SUBCASE("tts-voices-unsupported-language") {
    char* out = nullptr;
    CHECK(moonshine_get_tts_voices("zzz_not_a_supported_language", nullptr, 0,
                                   &out) == MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(out == nullptr);
  }

  SUBCASE("tts-voices-piper-de-includes-thorsten-stem") {
    const auto data_root = find_moonshine_tts_data_dir();
    if (!data_root) {
      MESSAGE("skip: moonshine-tts data directory not found");
      return;
    }
    const std::string g2p_root_str = data_root->string();
    const moonshine_option_t opts[] = {
        {"g2p_root", g2p_root_str.c_str()},
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_tts_voices("de", opts, 1, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"piper_de_DE-thorsten-medium\"") != std::string::npos);
    CHECK(json.find("\"state\":\"found\"") != std::string::npos);
    std::free(out);
  }

  SUBCASE("tts-voices-piper-en_us-includes-saikat-stem") {
    const auto data_root = find_moonshine_tts_data_dir();
    if (!data_root) {
      MESSAGE("skip: moonshine-tts data directory not found");
      return;
    }
    const std::string g2p_root_str = data_root->string();
    const moonshine_option_t opts[] = {
        {"g2p_root", g2p_root_str.c_str()},
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_tts_voices("en_us", opts, 1, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"piper_en_US-saikat\"") != std::string::npos);
    CHECK(json.find("\"state\":\"found\"") != std::string::npos);
    std::free(out);
  }

  SUBCASE("tts-zipvoice-dependencies") {
    const moonshine_option_t opts[] = {
        {"voice", "zipvoice_american_female"},
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_tts_dependencies("en_us", opts, 1, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"groups\"") != std::string::npos);
    CHECK(json.find("\"zipvoice/text_encoder.ort\"") != std::string::npos);
    CHECK(json.find("\"zipvoice/fm_decoder.ort\"") != std::string::npos);
    CHECK(json.find("\"zipvoice/vocoder.ort\"") != std::string::npos);
    CHECK(json.find("\"zipvoice/tokens.txt\"") != std::string::npos);
    CHECK(json.find("kokoro/model") == std::string::npos);
    CHECK(json.find("piper-voices") == std::string::npos);
    CHECK(json.find("\"role\":\"clone_asr\"") != std::string::npos);
    CHECK(json.find("\"clone_asr/") != std::string::npos);
    const bool has_attention =
        json.find("decoder_kv_with_attention.ort") != std::string::npos ||
        json.find("decoder_with_attention.ort") != std::string::npos;
    CHECK(has_attention);
    std::free(out);
  }

  SUBCASE("tts-zipvoice-voices-listing") {
    const moonshine_option_t opts[] = {
        {"voice", "zipvoice_american_female"},
        {"g2p_root", "/tmp"},
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_tts_voices("en_us", opts, 2, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"zipvoice_american_female\"") != std::string::npos);
    CHECK(json.find("\"zipvoice_indian_male\"") != std::string::npos);
    // No assets under /tmp, so ZipVoice voices report as missing.
    CHECK(json.find("\"state\":\"missing\"") != std::string::npos);
    CHECK(json.find("kokoro_") == std::string::npos);
    std::free(out);
  }
}

TEST_CASE("moonshine-stt-embedding-dependency-api") {
  SUBCASE("null-output-pointer") {
    CHECK(moonshine_get_stt_dependencies("en", nullptr, 0, nullptr) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(moonshine_get_embedding_dependencies("embeddinggemma-300m", nullptr,
                                               0, nullptr) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
  }

  SUBCASE("options-count-without-options-pointer") {
    char* out = nullptr;
    CHECK(moonshine_get_stt_dependencies("en", nullptr, 1, &out) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(moonshine_get_embedding_dependencies("embeddinggemma-300m", nullptr,
                                               1, &out) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
  }

  SUBCASE("stt-empty-language-is-invalid") {
    char* out = nullptr;
    CHECK(moonshine_get_stt_dependencies("", nullptr, 0, &out) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(out == nullptr);
  }

  SUBCASE("stt-english-default-is-medium-streaming") {
    // The first English model in the catalog is medium-streaming-en.
    char* out = nullptr;
    REQUIRE(moonshine_get_stt_dependencies("en", nullptr, 0, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"groups\"") != std::string::npos);
    CHECK(json.find("\"https://download.moonshine.ai/model/medium-streaming-en/"
                    "quantized_26_08_21\"") != std::string::npos);
    CHECK(json.find("\"adapter.ort\"") != std::string::npos);
    CHECK(json.find("\"frontend.model.ort\"") != std::string::npos);
    CHECK(json.find("\"frontend.weights.ort\"") != std::string::npos);
    CHECK(json.find("\"decoder_kv.ort\"") != std::string::npos);
    CHECK(json.find("\"streaming_config.json\"") != std::string::npos);
    // The attention decoder is only for word timestamps, so it is omitted
    // unless the caller asks for it (see
    // stt-english-streaming-word-timestamps).
    CHECK(json.find("\"decoder_kv_with_attention.ort\"") == std::string::npos);
    std::free(out);
  }

  SUBCASE("stt-english-streaming-word-timestamps-adds-attention-decoder") {
    // Passing the same word_timestamps option used to construct a transcriber
    // opts the optional attention decoder back into the manifest.
    const moonshine_option_t opts[] = {
        {"word_timestamps", "true"},
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_stt_dependencies("en", opts, 1, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"decoder_kv.ort\"") != std::string::npos);
    CHECK(json.find("\"decoder_kv_with_attention.ort\"") != std::string::npos);
    std::free(out);
  }

  SUBCASE("stt-english-tiny-non-streaming") {
    const moonshine_option_t opts[] = {
        {"model_arch", "0"},  // MOONSHINE_MODEL_ARCH_TINY
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_stt_dependencies("en", opts, 1, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"https://download.moonshine.ai/model/tiny-en/quantized/"
                    "tiny-en\"") != std::string::npos);
    CHECK(json.find("\"encoder_model.ort\"") != std::string::npos);
    CHECK(json.find("\"decoder_model_merged.ort\"") != std::string::npos);
    CHECK(json.find("\"tokenizer.bin\"") != std::string::npos);
    // The word-timestamp decoder is opt-in, so it is absent by default.
    CHECK(json.find("\"decoder_with_attention.ort\"") == std::string::npos);
    // Non-streaming must not list streaming files.
    CHECK(json.find("\"adapter.ort\"") == std::string::npos);
    std::free(out);
  }

  SUBCASE("stt-english-non-streaming-word-timestamps-adds-attention-decoder") {
    const moonshine_option_t opts[] = {
        {"model_arch", "0"},  // MOONSHINE_MODEL_ARCH_TINY
        {"word_timestamps", "true"},
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_stt_dependencies("en", opts, 2, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"decoder_with_attention.ort\"") != std::string::npos);
    std::free(out);
  }

  SUBCASE("stt-files-are-objects-with-name-url-size-checksum") {
    // The manifest schema deliberately makes each `files` entry an object
    // carrying name/url/size/checksum/checksum_type (not a bare string).
    const moonshine_option_t opts[] = {
        {"model_arch", "0"},  // MOONSHINE_MODEL_ARCH_TINY
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_stt_dependencies("en", opts, 1, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    // Object keys are present.
    CHECK(json.find("\"name\":\"encoder_model.ort\"") != std::string::npos);
    CHECK(json.find("\"url\":") != std::string::npos);
    CHECK(json.find("\"size\":") != std::string::npos);
    CHECK(json.find("\"checksum\":") != std::string::npos);
    CHECK(json.find("\"checksum_type\":") != std::string::npos);
    // Each file's url is the base_url joined with its name.
    CHECK(json.find("\"url\":\"https://download.moonshine.ai/model/tiny-en/"
                    "quantized/tiny-en/encoder_model.ort\"") !=
          std::string::npos);
    // `files` is no longer a bare string array, so the old shape must be gone.
    CHECK(json.find("\"files\":[\"") == std::string::npos);
    std::free(out);
  }

  SUBCASE("stt-non-english-omits-attention-extra") {
    const moonshine_option_t opts[] = {
        {"model_arch", "0"},  // MOONSHINE_MODEL_ARCH_TINY
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_stt_dependencies("ja", opts, 1, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"https://download.moonshine.ai/model/tiny-ja/quantized/"
                    "tiny-ja\"") != std::string::npos);
    CHECK(json.find("\"encoder_model.ort\"") != std::string::npos);
    CHECK(json.find("\"decoder_with_attention.ort\"") == std::string::npos);
    std::free(out);
  }

  SUBCASE("stt-english-name-lookup") {
    char* out = nullptr;
    REQUIRE(moonshine_get_stt_dependencies("English", nullptr, 0, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    std::free(out);
  }

  SUBCASE("stt-include-spelling-adds-group-for-english") {
    const moonshine_option_t opts[] = {
        {"model_arch", "0"},
        {"include_spelling", "true"},
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_stt_dependencies("en", opts, 2, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"https://download.moonshine.ai/model/spelling-en\"") !=
          std::string::npos);
    CHECK(json.find("\"spelling_cnn.ort\"") != std::string::npos);
    CHECK(json.find("\"spelling_cnn_meta.json\"") != std::string::npos);
    std::free(out);
  }

  SUBCASE("stt-include-spelling-noop-for-non-english") {
    const moonshine_option_t opts[] = {
        {"model_arch", "1"},  // MOONSHINE_MODEL_ARCH_BASE
        {"include_spelling", "true"},
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_stt_dependencies("es", opts, 2, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("spelling") == std::string::npos);
    std::free(out);
  }

  SUBCASE("stt-unknown-language") {
    char* out = nullptr;
    CHECK(moonshine_get_stt_dependencies("zzz_not_a_language", nullptr, 0,
                                         &out) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(out == nullptr);
  }

  SUBCASE("stt-unknown-arch-for-language") {
    // Base streaming (3) is the one architecture the catalog publishes for no
    // language at all, so it stays an unpublished combination as languages gain
    // models. This subcase previously asked for tiny streaming on Spanish,
    // which stopped being unpublished the moment Spanish shipped one.
    const moonshine_option_t opts[] = {
        {"model_arch", "3"},
    };
    char* out = nullptr;
    CHECK(moonshine_get_stt_dependencies("es", opts, 1, &out) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(out == nullptr);
  }

  SUBCASE("stt-invalid-arch-value") {
    const moonshine_option_t opts[] = {
        {"model_arch", "not-a-number"},
    };
    char* out = nullptr;
    CHECK(moonshine_get_stt_dependencies("en", opts, 1, &out) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(out == nullptr);
  }

  SUBCASE("embedding-default-variant-is-q4") {
    char* out = nullptr;
    REQUIRE(moonshine_get_embedding_dependencies("embeddinggemma-300m", nullptr,
                                                 0,
                                                 &out) == MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"https://download.moonshine.ai/model/"
                    "embeddinggemma-300m\"") != std::string::npos);
    // The model now ships as a single all-in-one .ort (no .onnx_data sidecar).
    CHECK(json.find("\"model_q4.ort\"") != std::string::npos);
    CHECK(json.find(".onnx_data") == std::string::npos);
    CHECK(json.find("\"tokenizer.bin\"") != std::string::npos);
    std::free(out);
  }

  SUBCASE("embedding-null-model-name-uses-default") {
    char* out = nullptr;
    REQUIRE(moonshine_get_embedding_dependencies(nullptr, nullptr, 0, &out) ==
            MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    CHECK(std::string(out).find("\"model_q4.ort\"") != std::string::npos);
    std::free(out);
  }

  SUBCASE("embedding-q8-maps-to-model-quantized") {
    // The C++ embedding loader resolves the q8 variant to model_quantized
    // (model_q8 is not published), so the manifest must match.
    const moonshine_option_t opts[] = {
        {"variant", "q8"},
    };
    char* out = nullptr;
    REQUIRE(moonshine_get_embedding_dependencies("embeddinggemma-300m", opts, 1,
                                                 &out) == MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"model_quantized.ort\"") != std::string::npos);
    CHECK(json.find("\"model_q8.ort\"") == std::string::npos);
    std::free(out);
  }

  SUBCASE("embedding-removed-variants-are-no-longer-supported") {
    const char* removed[] = {"fp32", "fp16", "q4f16"};
    for (const char* variant : removed) {
      const moonshine_option_t opts[] = {
          {"variant", variant},
      };
      char* out = nullptr;
      CHECK(moonshine_get_embedding_dependencies("embeddinggemma-300m", opts, 1,
                                                 &out) ==
            MOONSHINE_ERROR_INVALID_ARGUMENT);
      CHECK(out == nullptr);

      CHECK(moonshine_create_embedding_model(
                "/unused", MOONSHINE_EMBEDDING_MODEL_ARCH_GEMMA_300M,
                variant) == MOONSHINE_ERROR_INVALID_ARGUMENT);

      const char* names[] = {"model.ort"};
      const uint8_t dummy = 0;
      const uint8_t* memory[] = {&dummy};
      const uint64_t sizes[] = {1};
      CHECK(moonshine_create_embedding_model_from_memory(
                MOONSHINE_EMBEDDING_MODEL_ARCH_GEMMA_300M, variant, names, 1,
                memory, sizes, nullptr, 0,
                MOONSHINE_HEADER_VERSION) == MOONSHINE_ERROR_INVALID_ARGUMENT);
    }
  }

  SUBCASE("embedding-unknown-model") {
    char* out = nullptr;
    CHECK(
        moonshine_get_embedding_dependencies("not-a-model", nullptr, 0, &out) ==
        MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(out == nullptr);
  }

  SUBCASE("embedding-unknown-variant") {
    const moonshine_option_t opts[] = {
        {"variant", "q3"},
    };
    char* out = nullptr;
    CHECK(moonshine_get_embedding_dependencies("embeddinggemma-300m", opts, 1,
                                               &out) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(out == nullptr);
  }
}

TEST_CASE("moonshine-catalog-listing-api") {
  SUBCASE("stt-catalog-null-output") {
    CHECK(moonshine_get_stt_catalog(nullptr) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
  }

  SUBCASE("embedding-catalog-null-output") {
    CHECK(moonshine_get_embedding_catalog(nullptr) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
  }

  SUBCASE("stt-catalog-lists-languages-and-models") {
    char* out = nullptr;
    REQUIRE(moonshine_get_stt_catalog(&out) == MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"languages\"") != std::string::npos);
    CHECK(json.find("\"code\":\"en\"") != std::string::npos);
    CHECK(json.find("\"english_name\":\"English\"") != std::string::npos);
    CHECK(json.find("\"model_arch\":") != std::string::npos);
    CHECK(json.find("\"download_url\":") != std::string::npos);
    CHECK(json.find("\"is_default\":true") != std::string::npos);
    std::free(out);
  }

  SUBCASE("embedding-catalog-lists-models-and-variants") {
    char* out = nullptr;
    REQUIRE(moonshine_get_embedding_catalog(&out) == MOONSHINE_ERROR_NONE);
    REQUIRE(out != nullptr);
    const std::string json(out);
    CHECK(json.find("\"models\"") != std::string::npos);
    CHECK(json.find("\"name\":\"embeddinggemma-300m\"") != std::string::npos);
    CHECK(json.find("\"english_name\":\"Embedding Gemma 300M\"") !=
          std::string::npos);
    CHECK(json.find("\"variants\":") != std::string::npos);
    CHECK(json.find("\"default_variant\":\"q4\"") != std::string::npos);
    CHECK(json.find("\"fp32\"") == std::string::npos);
    CHECK(json.find("\"fp16\"") == std::string::npos);
    CHECK(json.find("\"q4f16\"") == std::string::npos);
    std::free(out);
  }
}

TEST_CASE("moonshine-extract-speech-clip-api") {
  const auto data_root = find_moonshine_tts_data_dir();
  if (!data_root) {
    MESSAGE("skip: moonshine-tts data directory not found");
    return;
  }
  const std::string model_root_str = data_root->string();
  const moonshine_option_t tts_opts[] = {
      {"model_root", model_root_str.c_str()},
      {"lang", "en_us"},
      {"voice", "kokoro_af_heart"},
  };
  const int32_t tts = moonshine_create_tts_synthesizer_from_files(
      "en_us", nullptr, 0, tts_opts,
      static_cast<uint64_t>(sizeof(tts_opts) / sizeof(tts_opts[0])),
      MOONSHINE_HEADER_VERSION);
  if (tts < 0) {
    MESSAGE("skip: could not create Kokoro TTS synthesizer");
    return;
  }

  SUBCASE("rejects bad arguments") {
    const std::vector<float> quiet(16000 * 6, 0.0f);
    moonshine_speech_clip_t clip{};
    CHECK(moonshine_extract_speech_clip(quiet.data(), quiet.size(), 16000, tts,
                                        nullptr, 0, nullptr) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(moonshine_extract_speech_clip(nullptr, 16, 16000, tts, nullptr, 0,
                                        &clip) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(moonshine_extract_speech_clip(quiet.data(), 0, 16000, tts, nullptr, 0,
                                        &clip) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(moonshine_extract_speech_clip(quiet.data(), quiet.size(), 0, tts,
                                        nullptr, 0, &clip) ==
          MOONSHINE_ERROR_INVALID_ARGUMENT);
    CHECK(moonshine_extract_speech_clip(quiet.data(), quiet.size(), 16000, -1,
                                        nullptr, 0, &clip) ==
          MOONSHINE_ERROR_INVALID_HANDLE);
  }

  SUBCASE("silence yields no clip") {
    const std::vector<float> quiet(16000 * 6, 0.0f);
    moonshine_speech_clip_t clip{};
    REQUIRE(moonshine_extract_speech_clip(quiet.data(), quiet.size(), 16000,
                                          tts, nullptr, 0,
                                          &clip) == MOONSHINE_ERROR_NONE);
    CHECK(clip.is_complete == 0);
    CHECK(clip.audio_data == nullptr);
    CHECK(clip.audio_length == 0);
    CHECK(clip.transcript == nullptr);
  }

  SUBCASE("speech yields a four second clip") {
    const std::string wav_path = "two_cities.wav";
    if (!std::filesystem::exists(wav_path)) {
      MESSAGE("skip: " << wav_path << " not found");
      return;
    }
    float* wav_data = nullptr;
    size_t wav_data_size = 0;
    int32_t wav_sample_rate = 0;
    REQUIRE(load_wav_data(wav_path.c_str(), &wav_data, &wav_data_size,
                          &wav_sample_rate));

    moonshine_speech_clip_t clip{};
    REQUIRE(moonshine_extract_speech_clip(wav_data, wav_data_size,
                                          wav_sample_rate, tts, nullptr, 0,
                                          &clip) == MOONSHINE_ERROR_NONE);
    CHECK(clip.is_complete == 1);
    REQUIRE(clip.audio_data != nullptr);
    CHECK(clip.audio_length == 4 * 16000);
    CHECK(clip.speech_duration >= 2.0f);
    // Kokoro TTS has no owned clone ASR, so transcript stays null.
    CHECK(clip.transcript == nullptr);
    moonshine_free_buffer(clip.audio_data);
  }

  SUBCASE("options control the clip length") {
    const std::string wav_path = "two_cities.wav";
    if (!std::filesystem::exists(wav_path)) {
      MESSAGE("skip: " << wav_path << " not found");
      return;
    }
    float* wav_data = nullptr;
    size_t wav_data_size = 0;
    int32_t wav_sample_rate = 0;
    REQUIRE(load_wav_data(wav_path.c_str(), &wav_data, &wav_data_size,
                          &wav_sample_rate));

    const moonshine_option_t options[] = {
        {.name = "clip_duration_seconds", .value = "2"},
        {.name = "minimum_speech_seconds", .value = "1"},
    };
    moonshine_speech_clip_t clip{};
    REQUIRE(moonshine_extract_speech_clip(wav_data, wav_data_size,
                                          wav_sample_rate, tts, options, 2,
                                          &clip) == MOONSHINE_ERROR_NONE);
    CHECK(clip.is_complete == 1);
    REQUIRE(clip.audio_data != nullptr);
    CHECK(clip.audio_length == 2 * 16000);
    moonshine_free_buffer(clip.audio_data);
  }

  moonshine_free_tts_synthesizer(tts);
}

// Full ZipVoice synthesis needs the model bundle under ``<data>/zipvoice`` (not
// committed in bulk). These cases exercise the built-in-voice and user-PCM
// paths when the assets are present, and skip cleanly otherwise.
TEST_CASE("moonshine-tts-zipvoice-synthesis") {
  const auto data_root = find_moonshine_tts_data_dir();
  if (!data_root) {
    MESSAGE("skip: moonshine-tts data directory not found");
    return;
  }
  const std::filesystem::path zv = *data_root / "zipvoice";
  const bool have_models =
      std::filesystem::is_regular_file(zv / "text_encoder.ort") &&
      std::filesystem::is_regular_file(zv / "fm_decoder.ort") &&
      std::filesystem::is_regular_file(zv / "vocoder.ort") &&
      std::filesystem::is_regular_file(zv / "tokens.txt");
  if (!have_models) {
    MESSAGE("skip: ZipVoice model bundle not present under data/zipvoice");
    return;
  }
  const std::string g2p_root_str = data_root->string();

  SUBCASE("builtin-voice-synthesizes-audio") {
    const moonshine_option_t create_opts[] = {
        {"voice", "zipvoice_american_female"},
        {"g2p_root", g2p_root_str.c_str()},
    };
    const int32_t h = moonshine_create_tts_synthesizer_from_files(
        "en_us", nullptr, 0, create_opts,
        static_cast<uint64_t>(sizeof(create_opts) / sizeof(create_opts[0])),
        MOONSHINE_HEADER_VERSION);
    REQUIRE(h >= 0);
    float* audio = nullptr;
    uint64_t n = 0;
    int32_t sr = 0;
    REQUIRE(moonshine_text_to_speech(h, "Hello there, this is a test.", nullptr,
                                     0, &audio, &n,
                                     &sr) == MOONSHINE_ERROR_NONE);
    CHECK(sr == 24000);
    CHECK(n > 0);
    if (audio != nullptr) {
      std::free(audio);
    }
    moonshine_free_tts_synthesizer(h);
  }

  SUBCASE("user-pcm-with-explicit-transcript") {
    // A short synthetic reference clip (silence + tone) suffices to exercise
    // the memory + clone path.
    std::vector<float> pcm(24000, 0.f);
    for (size_t i = 0; i < pcm.size(); ++i) {
      pcm[i] = 0.05f * std::sin(2.0 * 3.14159265 * 150.0 * i / 24000.0);
    }
    const char* filenames[] = {"zipvoice/clone_audio"};
    const uint8_t* mem[] = {reinterpret_cast<const uint8_t*>(pcm.data())};
    const uint64_t sizes[] = {pcm.size() * sizeof(float)};
    const moonshine_option_t create_opts[] = {
        {"voice", "zipvoice"},
        {"g2p_root", g2p_root_str.c_str()},
        {"zipvoice_clone_sample_rate", "24000"},
        {"zipvoice_clone_transcript", "This is a reference clip."},
    };
    const int32_t h = moonshine_create_tts_synthesizer_from_memory(
        "en_us", filenames, 1, mem, sizes, create_opts,
        static_cast<uint64_t>(sizeof(create_opts) / sizeof(create_opts[0])),
        MOONSHINE_HEADER_VERSION);
    REQUIRE(h >= 0);
    float* audio = nullptr;
    uint64_t n = 0;
    int32_t sr = 0;
    REQUIRE(moonshine_text_to_speech(h, "Testing one two three.", nullptr, 0,
                                     &audio, &n, &sr) == MOONSHINE_ERROR_NONE);
    CHECK(sr == 24000);
    if (audio != nullptr) {
      std::free(audio);
    }
    moonshine_free_tts_synthesizer(h);
  }
}
