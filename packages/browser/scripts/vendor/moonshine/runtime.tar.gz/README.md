Moonshine 0.1.5-ears.1: pinned eaRS final-audio repair. No ASR models included.
